SELECT COUNT(ET.EmployeeID) [Jumlah Employee], R.RegionDescription [Region Description]
FROM EmployeeTerritories ET 
JOIN Territories T ON ET.TerritoryID = T.TerritoryID
JOIN Region R ON T.RegionID = R.RegionID
GROUP BY RegionDescription
ORDER BY [Jumlah employee] DESC
