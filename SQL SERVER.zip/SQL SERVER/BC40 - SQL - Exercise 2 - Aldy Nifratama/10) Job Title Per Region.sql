select * 
from (select E.Title, R.RegionDescription,ET.EmployeeID
	from EmployeeTerritories [ET]
	JOIN Employees [E] ON ET.EmployeeID=E.EmployeeID
	JOIN Territories [T] ON ET.TerritoryID=T.TerritoryID
	JOIN Region [R] ON T.RegionID=R.RegionID
	
) [K] 
PIVOT (
COUNT (K.EmployeeID)
	FOR K.RegionDescription IN (Northern,Eastern,Southern,Western)
) AS PVT
ORDER BY PVT.Title

