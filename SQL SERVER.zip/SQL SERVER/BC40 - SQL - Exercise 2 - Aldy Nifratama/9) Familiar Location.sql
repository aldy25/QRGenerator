select distinct e.Country [negara], s.CompanyName [Nama Supliers], e.FirstName [Nama Employe],e.HomePhone [Phone Employee], s.Phone[Phone Supliers]
 from Employees [e]
 join  Suppliers [s] on e.Country = s.Country
 order by [nama employe]




