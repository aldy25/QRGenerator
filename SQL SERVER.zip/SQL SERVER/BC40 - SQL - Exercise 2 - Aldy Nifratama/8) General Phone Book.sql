select c.CompanyName [fullname],c.Phone [nomor phone],'Customer' [EntityType]
from Customers [c] 
union
select s.CompanyName [fullname],s.Phone [nomor phone],'Suppliers' [EntityType]
from Suppliers [s]
union
select CONCAT(e.FirstName,e.LastName) [fullname],e.HomePhone [nomor phone],'Employees'[EntityType]
from Employees [e] 
ORDER BY [fullname]  DESC

;


