USE Northwind;
GO

/*
	User-defined table type adalah table yang dibuat, gunakanya sebagai tipe data dalam specific table, dimana user-defined table bisa digunakan
	sebagai variable atau temporary storage, yang nantinya bisa kita passing ke dalam parameter.

	Karena adanya user-defined table type, sebuah table jadi memungkin-kan untuk dijadikan argument atau dipassing ke dalam function.
	Parameter yang bisa menerima sebuah user-defined table sebagai argumentnya, disebut juga Table-Valued Parameter.

	Keuntungan dari Table-Valued Parameters dan User-Defined Table type adalah memberikan performance yang lebih baik dari Temporary Table,
	dan menyederhanakan alur pemrograman T-SQL
*/

--membuat variable untuk table
DECLARE @sebuahTabel AS table(
	OrderID int,
	CustomerID varchar(10),
	OrderDate datetime,
	ShippedDate datetime,
	ProductInOrder int
)
INSERT INTO @sebuahTabel
SELECT ord.OrderID,ord.CustomerID,ord.OrderDate,ord.ShippedDate,
		COUNT(orDet.OrderID) [ProductInOrder]
FROM Orders [ord]
JOIN [Order Details] [orDet] ON ord.OrderID=orDet.OrderID
GROUP BY ord.OrderID,ord.CustomerID,ord.OrderDate,ord.ShippedDate
SELECT * FROM @sebuahTabel;



--BERIKUT ADALAH CONTOH PENGGUNAAN USER DEFINIED TABLE TYPE
--Membuat sebuah tipe data (secara spesifik tipe datanya dari tabel)
CREATE TYPE OrderWithProductQuantity AS TABLE
(
	OrderID int,
	CustomerID varchar(10),
	OrderDate datetime,
	ShippedDate datetime,
	ProductInOrder int

);
--DROP TYPE OrderWithProductQuantity
--BUAT TABLE NYA
DECLARE @sebuahDefinedTableType OrderWithProductQuantity;
--SET NILAINYA
INSERT INTO @sebuahDefinedTableType
SELECT ord.OrderID,ord.CustomerID,ord.OrderDate,ord.ShippedDate,
		COUNT(orDet.OrderID) [ProductInOrder]
FROM Orders [ord]
JOIN [Order Details] [orDet] ON ord.OrderID=orDet.OrderID
GROUP BY ord.OrderID,ord.CustomerID,ord.OrderDate,ord.ShippedDate;
SELECT * FROM @sebuahDefinedTableType;
--Northwind -> Programmability -> Types -> User-Defined Data Type

