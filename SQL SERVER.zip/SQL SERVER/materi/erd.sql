/*
ERD (Entity Relationship Diagram)
Entity ->Entitas (sesuatu yang independen) contohnya adalah  tabel mahasiswa dan tabel KamarAsrama

ada 3 bentuk Relationship
1. one to one
2. one to many
3. many to many

cardinal yang akan dipakai menggunakan notasi crow's foot

---+ one    ----<- many
ASSOCIATION TABLE ADALAH TABEL YG DIBUAT UNTUK MENORMALISASI RELASI
*/

/*
BEDA DATA MASTER DAN DATA TRANSACTION

>MASTER
	1. Datanya dapat berubah sewaktu waktu
	2. Datanya Lebih Sedikit 
>TRANSACTION
	1. Datanya Tidak boleh diubah
	2. Jumlah transaksi jauh lebih banyak
	3. interaksi antara 1 tabel atau lebih
*/

---mandatory dan optional

