USE master;
--Transact SQL (T-SQL) : extensi dari sql server DBMS untuk logika pemrograman
/*
conditional statment -> if else
*/
--jika benar maka jalankan statement nya
--jika salah maka statmen tidak di jalankan

--BEGIN DAN END DIGUNAKAN UNTUK MELAKUKAN LEBIH DARI 1 STATMENT JIKA KONDISI TERPENUHI
if (1=0) PRINT '1=0'
ELSE PRINT '1=1';

--penggunaan while loop
DECLARE @NILAI INT =0;
WHILE(@NILAI <=10)
BEGIN
	IF (@NILAI % 2 = 0) 
		
			PRINT CAST(@NILAI AS VARCHAR(50)) + ' = BILANGAN GENAP';
		
	ELSE
		
			PRINT CAST(@NILAI AS VARCHAR(50)) + ' = BILANGAN GANJIL'; 
	SET @NILAI = @NILAI +1;
END

--berikut penggunaan case dalam sql server
USE Northwind;
SELECT prod.ProductName AS [Name],
CASE
	WHEN prod.UnitPrice < 10 THEN 'Cheap'
	WHEN prod.UnitPrice >= 10 AND prod.UnitPrice < 20 THEN 'Regular'
	WHEN prod.UnitPrice > 20 THEN 'Expensive'
	ELSE 'N/A'
END AS PriceLevel
FROM dbo.Products AS prod;
go
--berikut contoh penggunaan case jg
SELECT pro.ProductID,pro.ProductName,pro.UnitPrice,
	CASE 
		WHEN (pro.Discontinued =1) THEN 'Tidak Di Lanjutkan'
		ELSE 'Masih Menerima Produk Baru'
	END [Discontinued],
	CASE 
		WHEN (pro.UnitPrice >100) THEN 'Mahal'
		WHEN (pro.UnitPrice between 10 AND 100) THEN 'Terjangkau'
		WHEN (pro.UnitPrice < 10) THEN 'Murah'
	END [Opini Harga]
FROM Products [pro]

--IIF (Kondisi, Benar, Salah)

--case digantikan dengan IIF
SELECT pro.ProductID,pro.ProductName,pro.UnitPrice,
	IIF (pro.Discontinued =1,
		'Tidak Di Lanjutkan',
		'Masih Menerima Produk Baru'
	) [Discontinued],
	IIF (pro.UnitPrice >100,
		'Mahal',
		IIF (pro.UnitPrice >10,
				'Terjangkau',
				'Murah'
			)
		) [Opini Harga]
FROM Products [pro];

--while yaitu jika masih benar maka statment akan dijalankan
WHILE (1=1)
	PRINT 'Statment ini akan terus dijalankan';
------------------------------------------------------
/*
	1. kondisi yang tidak konstan
	2. kondisi yang harus diubah didalam conditional statementnya

*/
--fibbonace squence
DECLARE @nilaipertama int=0;
DECLARE @nilaikedua int=1;
DECLARE @hasil int;
DECLARE @perulangan int=0;

WHILE (@perulangan <10 AND @nilaipertama < 1000)
	BEGIN
		PRINT @nilaipertama
		SET @hasil=@nilaipertama +@nilaikedua
		SET @nilaipertama=@nilaikedua
		SET @nilaikedua=@hasil
		SET @perulangan = @perulangan +1

	END;
----------------------------------------------------------
--mencetak bilangan prima kesamping
----------------------------------------------------------
	DECLARE @lop1 INT = 1
    DECLARE @lop2 INT = 2
    DECLARE @jumlah INT
    DECLARE @prima AS VARCHAR(1000)
    BEGIN
    WHILE @lop2 <= 100
        BEGIN
            SET @jumlah = 0
            WHILE (@lop1 <= @lop2)
                BEGIN
                    BEGIN
                        IF((@lop2 % @lop1) = 0)
                            SET @jumlah += 1
                    END
                    SET @lop1 += 1
                END
            BEGIN
                IF (@jumlah = 2)
                    SET @prima = CONCAT_WS(' ', @prima, @lop2)
            END
            SET @lop1 = 1
            SET @lop2 += 1
        END
    END;
    PRINT @prima
go
---mencetak bilangan prima ke bawah
	DECLARE @lop1 INT = 1
    DECLARE @lop2 INT = 2
    DECLARE @jumlah INT
    DECLARE @prima AS VARCHAR(1000)
    WHILE (@lop2 <= 100)
        BEGIN
            SET @jumlah = 0
            WHILE (@lop1 <= @lop2)
                BEGIN
                    BEGIN
                        IF((@lop2 % @lop1) = 0)
                            SET @jumlah += 1
                    END
                    SET @lop1 += 1
                END
            BEGIN
                IF (@jumlah = 2)
                   BEGIN
					PRINT @lop2
				   END
            END
            SET @lop1 = 1
            SET @lop2 += 1
        END
go
----
--ROWCOUNT akan memberikan hasil count row dari query sebelumnya
SELECT * FROM Customers
ORDER BY CustomerID --91

DECLARE @jumlahCustomer int = @@ROWCOUNT
DECLARE @penghitung int =0
WHILE (@penghitung <@jumlahCustomer)  --Akan loop sebanyak 91 kali
	BEGIN
		DECLARE @customer VARCHAR(10);
		SELECT @customer =CustomerID
		FROM  Customers
		ORDER BY CustomerID
		OFFSET @penghitung ROWS
		FETCH NEXT 1 ROWS ONLY;

		IF (@penghitung =0)
			BEGIN
				SET @penghitung+=1;
				CONTINUE				--walaupun statement belum selesai, akan kembali lagi ke atas 
			END

		IF (@penghitung=9)
			BREAK;						--walaupun statementnya belum selesai, akan berhenti loop
		PRINT @customer;
		SET @penghitung +=1;
	END


