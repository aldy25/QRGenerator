DECLARE @Lebaran AS date='9 March 2024';
PRINT @Lebaran

--yyyy-MM-dd(format date paling aman)
--MM-dd-yyyy (terkadang suka keliru karena format kita dd-MM-yyyy)

--dd MMMM yyyy
SET @Lebaran ='31 March 2024';
SET @Lebaran ='2024-03-31';								--
SET @Lebaran = PARSE('1 Maret 2024' AS date USING 'id') --parse date 

PRINT @Lebaran
PRINT FORMAT(@Lebaran, 'dddd,dd MMMM yyyy','id')
PRINT GETDATE();

DECLARE @SebuahDateTime  AS datetime = '31 March 2024 12:30:55';
PRINT FORMAT(@SebuahDateTime,'MM,mm');

PRINT DATENAME(day,@SebuahDateTime);
PRINT DATENAME(month,@SebuahDateTime);
PRINT DATENAME(year,@SebuahDateTime);
PRINT DATENAME(hour,@SebuahDateTime);
PRINT DATENAME(minute,@SebuahDateTime);
PRINT DATENAME(second,@SebuahDateTime);

--untuk menambah waktu
PRINT DATEADD(day,5,@SebuahDateTime);
PRINT DATEADD(month,5,@SebuahDateTime);
PRINT DATEADD(year,5,@SebuahDateTime);
PRINT DATEADD(hour,5,@SebuahDateTime);
PRINT DATEADD(minute,5,@SebuahDateTime);
PRINT DATEADD(second,6,@SebuahDateTime);


--end of month
--UNTUK MENGETAHUI WAKTU TERAKHIR DALAM SATU BULAN
PRINT EOMonth('15 February 2023'); --28
PRINT EOMonth('15 February 2024'); --29

DECLARE @natal2023 as DATE ='25 DECEMBER 2023';
DECLARE @natal2024 as DATE ='25 DECEMBER 2024';

PRINT DATEDIFF(day,@natal2023,@natal2024);
PRINT DATEDIFF(month,@natal2023,@natal2024);
PRINT DATEDIFF(year,@natal2023,@natal2024);

PRINT ISDATE('12 MARCH 2024 12:00'); --0 BILA BUKAN DATETIME.1 BILA DATETIME

--KESIMPULAN
/*
1.BISA MELIHAT SALAH SATU (HOUR,MINUTE,DLL) DARI SEBUAH WAKTU
2.BISA MENAMBAHKAN ATAU MENGURANGI WAKTU
3.BISA MEMBANDINGKAN ANTARA 2 WAKTU
*/