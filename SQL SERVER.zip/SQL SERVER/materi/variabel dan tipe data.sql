
--mendeklarasikan variabel dengan tipe data tinyint
DECLARE @nilaiInt As tinyint;

--variabel @nilaiTiniInt kita kasih nilai 0-255
set @nilaiInt =0

select @nilaiInt

--decimal value
--decimal(precision, class)

declare @nilaiDecimal as decimal(5,2);
set @nilaiDecimal =3;
select @nilaiDecimal;

--float

declare @nilaiFloat as float(2)=344;
print @nilaiFloat;

--samalmoney : tipe data finansial dengan range -214.214,3648 - 214.748.3647
declare @nilaiSmallMoney as smallmoney  =214748.2;
print @nilaiSmallMoney

--money: tipe data finansial dengan range -922.337.203.685.477,5808 - 922.337.203.685.477.5808
declare @nilaiMoney as money = 99999999999.3
print @nilaiMoney

--bit : digunakan untuk nilai 0 atau 1 saja, biasanya digunakan untuk true / false juga
declare @nilaiBit as bit=0;
print @nilaiBit ;


--character / string values
declare @nilaiChar as char(2)='y';
print @nilaiChar

--varchar mengeleminasi whitespace yang tidak diketik
declare @nilaiVarChar as varchar(8000)='y';
print @nilaiVarChar

-- nvarchar dapat membaca char yang tidak terdaftar. nvarchar menggunakan utf-16
declare @nilainVarChar as nvarchar(2)='y';
print @nilainVarChar

/*
datetame : 1 januari 1753-31 december 9999 (minimal-maximal)
datetame2 :  1 januari 0001 - 31 december 9999(minimal-maximal)
datetimeoffset : membawa perbedaan GMT (Greenwich mean time)
*/


--kelompok time values
declare @nilaiTime as time ='17:50'
print @nilaiTime

--kelompok time values
declare @nilaiDateTime as datetime ='2000-12-02 10:00'
print @nilaiDateTime

--kelompok time values
declare @nilaiDate as date ='2000-12-02';
set @nilaiDate='2000-12-03';
print @nilaiDate;

--nomor dapat kita gunakan operasi matematika

declare @nilaiIntHitung as int;
set @nilaiIntHitung=10;
print @nilaiIntHitung * 2;


--bilangan numerik juga bisa digunakan untuk operasi matematika
declare @discountPresentase AS float =0.2;
select  ProductName,
		UnitPrice,
		(UnitPrice * @discountPresentase) [Discount] ,
		UnitPrice - (UnitPrice * @discountPresentase) [New Price]
from Products;

--sQRT (SQUARE ROOT DAN POWER)
declare @nilaiSqrt AS int =81;
print SQRT(@nilaiSqrt); --AKAR
PRINT POWER(@nilaiSqrt, 2); --KUADRAT

/*
	Ada 3 macam pembulatan:
	FLOOR: Pembulatan ke bawah untuk semua nilai desimal.
	CEILING: Pembulatan ke atas untuk semua nilai desimal.
	ROUND: Pembulatan relative untuk semua nilai desimal.
*/

DECLARE @high AS DECIMAL(5,2) = 56.88, @low AS DECIMAL(5,2) = 56.12;
PRINT FLOOR(@high);
PRINT FLOOR(@low);				--NILAI TERENDAH
PRINT CEILING(@high);			--NILAI TERTINGGI
PRINT CEILING(@low);			--NIAI TERTINGGI

--Round memiliki parameter angka dibelakang untuk menyatakan berapa jumlah presisinya.
PRINT ROUND(@high, 1);
PRINT ROUND(@high, 0);
PRINT ROUND(@low, 1);
PRINT ROUND(@low, 0);

--TIPE DATA CHARACTER / STRING
--FUNGSI LEN AKAN MENGHITUNG SPASI TETAPI TIDAK UNTUK SPASI YANG DIBELAKANG CARACTER
DECLARE @sebuahChar AS CHAR(10) ='TEST';
DECLARE @sebuahVarchar AS VARCHAR(10) ='TEST';
DECLARE @sebuahINT AS INT =10000;

PRINT LEN(@sebuahChar)
PRINT LEN(@sebuahVarchar)
PRINT DATALENGTH(@sebuahINT)

--ASSIGN PADA SAAT SELECT
DECLARE @namaKariyawan AS varchar(100);
SELECT @namaKariyawan = CONCAT(FirstName,' ',LastName)
FROM Employees
WHERE EmployeeID=1;
SELECT @namaKariyawan;
/*
	UPPER digunakan untuk merubah semua character pada string menjadi Uppercase atau huruf besar.
	LoWER digunakan untuk merubah semua character pada string menjadi Lowercase atau huruf kecil.
*/

DECLARE @Nama as VARCHAR(20)='Aldy Nifratama';
PRINT UPPER(@Nama);
PRINT LOWER(@Nama);


/*PATINDEX mencari index dari pattern yang ingin dicari. akan mengembalikan index pertamanya*/
PRINT PATINDEX('%ni%',@Nama);
PRINT PATINDEX('Aldy Nifratama',@Nama);

/*
	Triming Function digunakan untuk menghilangkan gap di ujung depan dan belakang dari suatu string (bukan bagian tengah).
	LTRIM: Menghilangkan spasi atau gap pada bagian depan/kiri string
	RTRIM: Menghilangkan spasi atau gap pada bagian belakang/kanan string
*/
DECLARE @wrongInput varchar(200) = '   Test    Big   Gap   ';
PRINT RTRIM(@wrongInput);
PRINT LTRIM(@wrongInput);
PRINT RTRIM(LTRIM(@wrongInput));


/*
	SUBSTRING digunakan untuk mengambil potongan string dari satu index ke n banyak character selanjutnya.
	SUBSTRING(string_variable, index _start, panjang_char)
*/
DECLARE @lorem varchar(200) = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.';
PRINT SUBSTRING(@lorem, 1, 5);
PRINT SUBSTRING (@lorem, PATINDEX('%Lorem%',@lorem),11);


/*LEFT: hampir mirip seperti substring, tetapi diambil dari index paling kiri*/
PRINT LEFT(@lorem, 5);

/*RIGHT: hampir mirip seperti substring, tetapi diambil dari index paling kanan*/
PRINT RIGHT(@lorem, 9);

/*REPLACE: mengganti sepotong string pada variable dengan sepotong string lainnya.*/
PRINT REPLACE(@lorem,'l', 'x');
PRINT REPLACE(@lorem,' ', '/'); --Mengganti satu potong string

/*REPLICATE: print sebuah string berulang kali, jumlah perulangan sesuai dengan parameternya.*/

DECLARE @Aldy AS VARCHAR(20)='Aldy Nifratama';
PRINT REPLICATE('Aldy ', 8);
PRINT REPLICATE(SUBSTRING(@Aldy,1,5) , 4);

--mengubah tipe data menjadi yang kita mau
DECLARE @NOMOR AS INT =42;
PRINT CONCAT('Kamar Nomor. ', STR(@NOMOR,2));
PRINT STR(@NOMOR,2) + 5;
/*
	STR adalah method yang digunakan untuk meng-convert from Numeric to String
	parameter kedua berisi total character, by default 10
	parameter ketiga berisi total angka dibelakang koma untuk desimal
*/
DECLARE @INT AS FLOAT=22;
DECLARE @FLOAT AS DECIMAL(4,2)=@INT/7;
PRINT STR(@FLOAT,4,2);

/*
	PARSE: method yang digunakan untuk merubah string menjadi data type yang lain
*/


DECLARE @VAR AS VARCHAR(100)='125.5';
PRINT TRY_PARSE(@VAR AS FLOAT); --MENGUBAH DARI STRING MENJADI FLOAT
PRINT TRY_PARSE(@VAR AS INT(3)); --KALO ERROR, DIA AKAN NULL DAN KALO BERHASIL AKAN NORMAL SEPERTI PARSE
--FORMAT PENULISAN
/*
C:Currency
G:General
N:Number
*/
DECLARE @uangJajan AS VARCHAR(100)= '$1,250,000.5';
DECLARE @perseduangJajan AS money= PARSE(@uangJajan AS money);

--link format
--https://learn.microsoft.com/en-us/bingmaps/rest-services/common-parameters-and-types/supported-culture-codes
PRINT FORMAT(@perseduangJajan,'C','id');
PRINT FORMAT(@perseduangJajan,'G','id');
PRINT FORMAT(@perseduangJajan,'N','id');


