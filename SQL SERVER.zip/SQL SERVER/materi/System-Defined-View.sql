USE Northwind;
/*Melihat semua informasi column yang ada.*/

SELECT * FROM INFORMATION_SCHEMA.COLUMNS;

--UNTUK MELIHAT SEMUA INFORMASI VIEWS YANG ADA
SELECT * FROM INFORMATION_SCHEMA.VIEWS;

--untuk mengambil view_definition (query dalam view)
DECLARE @QueryDariView AS VARCHAR(1000) = (
	SELECT VIEW_DEFINITION
	FROM INFORMATION_SCHEMA.VIEWS
	WHERE TABLE_NAME = 'Order With Product Quabtity'
)
PRINT @QueryDariView;


SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Employees';
SELECT * FROM INFORMATION_SCHEMA.CHECK_CONSTRAINTS;
SELECT * FROM INFORMATION_SCHEMA.TABLES;
/*
INFORMATION SCHEMA
STANDARD Catalog metadata yang digunakan untuk melihat informasi "fisik" dari database

sys Catalog View
metadata catalog yang dibuat pada saat pembuatan sql server pertama kali.
information schema juga banyak menggunakan sys catalog

*/

SELECT session_id, login_time, [program_name]
FROM sys.dm_exec_sessions
WHERE is_user_process = 1;




