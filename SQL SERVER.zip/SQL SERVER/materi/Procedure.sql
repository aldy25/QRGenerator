/*
	STORED PROCEDURE / PROCEDURE
	mirip seperti function namun:
	1. TIDAK HARUS Mengembalikan sebuah nilai
	2. Bisa menggunakan function , view , base_table  yang ada di database

*/
USE Northwind;
GO
CREATE OR ALTER PROCEDURE GetEmployees AS
BEGIN
	SELECT * FROM Employees
	SELECT * FROM Orders
END
GO
EXECUTE GetEmployees;
/*
	dapat mengumpulkan beberapa query yang menghasilkan sesuatu,
	namun seluruh hasil-hasil tersebut belum tentu bisa digunakan
*/
--CONTOH Procedure optional untuk memiliki sebuah paramater sebagai output
GO
CREATE OR ALTER PROCEDURE GetEmployeesByCity 
	(@city varchar(50),
	@title VARCHAR(100))
	AS
BEGIN
	SELECT * FROM Employees
	WHERE 
		City LIKE '%'+@city+'%' AND Title LIKE '%'+@title+'%'
	
	--SETELAH 
	SELECT DISTINCT City,Title FROM Employees
END
GO
EXEC dbo.GetEmployeesByCity 'Seattle','Inside';
GO


--CONTOH Procedure optional untuk memiliki sebuah paramater sebagai ouput
GO
CREATE OR ALTER PROCEDURE SearchEmployees 
	(
	@city varchar(50),
	@title VARCHAR(100),
	@status VARCHAR(100) OUTPUT ---BERHASIL ATAU GAGAL
	)
	AS
BEGIN
	SELECT * FROM Employees
	WHERE 
		City LIKE '%'+@city+'%' AND Title LIKE '%'+@title+'%'
	

	IF(@@ROWCOUNT>0)
		SET @status='Berhasil'
	ELSE
		SET @status='Gagal'

	--SETELAH 
	SELECT DISTINCT City,Title FROM Employees
END
GO

DECLARE @penampungOutput varchar(50);
EXEC SearchEmployees'Seattle','Inside', @penampungOutput OUTPUT;
PRINT @penampungOutput;
