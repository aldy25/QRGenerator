/*
 Temporary Table adalah table sementara, dimana table ini hanya menampung data sementara di dalam database.
 Data-data temporary table diperoleh dari table normal untuk waktu yang limited.

 Temporary table digunakan saat ada data yang banyak di dalam table, dan kita harus berulang kali berinteraksi dengan 
 sebagian kecil dari data yang banyak.
 Daripada harus difilter berkali-kali, Temporary table bisa dimanfaatkan untuk menampungnya sementara.
*/

USE Northwind;
GO 
SELECT  City
INTO #CityEmployees
FROM Employees;
SELECT  City
INTO ##CityEmployees
FROM Employees;
--KALAU temporery table sudah dibuat, maka dia  bisa dianggap sebagai table value biasa.
SELECT * FROM #CityEmployees;

--dapat digunakan di koneksi yang berbeda karna menggunakan ##
SELECT * FROM ##CityEmployees;
--Temporary Tables bisa ditemuka di Databases > System Databases > tempdb > Temporary Tables

--temporary tabel juga bisa di hapus menggunakan drob table
DROP TABLE ##CityEmployees;

-- variable lokal dengan tipedata tabel
DECLARE @VariableTable AS TABLE(City VARCHAR(50));

INSERT INTO @VariableTable
SELECT City FROM Employees;
SELECT * FROM @VariableTable;

--