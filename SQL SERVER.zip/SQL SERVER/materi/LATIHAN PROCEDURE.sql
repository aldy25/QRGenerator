CREATE DATABASE ShoppingCartDemo

GO

USE ShoppingCartDemo;
GO

CREATE TABLE Product(
	ID int IDENTITY(1,1) PRIMARY KEY,
	Name varchar(100),
	UnitPrice money CHECK(UnitPrice >= 0),
	UnitsInStock int CHECK(UnitsInStock >= 0)
)

CREATE TABLE Customer(
	ID int IDENTITY(1,1) PRIMARY KEY,
	FirstName varchar(50),
	LastName varchar(50)
)

CREATE TABLE Cart(
	PRIMARY KEY (CustomerID, ProductID),
	CustomerID int REFERENCES Customer(ID),
	ProductID int REFERENCES Product(ID),
	Quantity int CHECK(Quantity >= 0)
)

CREATE TABLE [Order](
	ID int PRIMARY KEY IDENTITY(100, 1),
	CustomerID int REFERENCES Customer(ID),
)

CREATE TABLE [Order Detail](
	PRIMARY KEY (OrderID, ProductID),
	OrderID int REFERENCES [Order](ID),
	ProductID int REFERENCES Product(ID),
	Quantity int
)

GO

INSERT INTO Product VALUES ('Laptop', 1000, 2)

INSERT INTO Customer VALUES('Zaidan', 'Gigan')

INSERT INTO Cart VALUES(1, 1, 2);

go
CREATE OR ALTER PROCEDURE PindahKeranjang
	(
		@custumerID int,
		@productID int
		
	)
AS
BEGIN
	DECLARE @orderID INT;
	DECLARE @unitInStock INT;
	DECLARE @stokbaru INT;
	DECLARE @quantity INT;
	INSERT INTO [Order] 
		VALUES(@custumerID)
	
	SET @orderID= (SELECT TOP 1 ID FROM [Order]
		ORDER BY ID DESC)
	INSERT INTO [Order Detail] 
		VALUES(@orderID,@productID,@quantity)
	
	SET @quantity = (SELECT Quantity FROM Cart WHERE CustomerID=@custumerID AND ProductID=@productID) 
	SET @unitInStock=(SELECT UnitsInStock
		FROM Product
		WHERE ID=@productID)
	SET @stokbaru= @unitInStock-@quantity
	UPDATE Product
		SET UnitsInStock=@stokbaru
	DELETE Cart WHERE CustomerID=@custumerID AND ProductID=@productID
END
GO
EXEC PindahKeranjang 1,1
----------------------------------------------------------
---contoh penggunaan rollback and commmit
--------------------------------------------------------


CREATE OR ALTER PROCEDURE PindahKeranjang
	(
		@custumerID int,
		@productID int
		
	)
AS
BEGIN
	DECLARE @orderID INT;
	DECLARE @unitInStock INT;
	DECLARE @quantity INT;

	BEGIN TRANSACTION
-----------------------------------------------
		INSERT INTO [Order] 
			VALUES(@custumerID)
--------------------------------------------------
			SET @orderID= (SELECT TOP 1 ID FROM [Order]
		ORDER BY ID DESC)
-------------------------------------------------
		INSERT INTO [Order Detail] 
		VALUES(@orderID,@productID,@quantity)
-------------------------------------------------
			SET @quantity = (SELECT Quantity FROM Cart WHERE CustomerID=@custumerID AND ProductID=@productID) 
-----------------------------------------------
			SET @unitInStock=(SELECT UnitsInStock FROM Product WHERE ID=@productID)
------------------------------------------------
		

			DELETE Cart WHERE CustomerID=@custumerID AND ProductID=@productID
-----------------------------------------------
		BEGIN TRY
			UPDATE Product SET UnitsInStock=@unitInStock-@quantity WHERE ID=@productID
			COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK	
		END CATCH
END
GO
EXEC PindahKeranjang 1,1
