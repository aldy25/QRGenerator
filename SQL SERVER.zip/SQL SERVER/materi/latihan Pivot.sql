--latihan soal

SELECT *
FROM (
	SELECT  Title,City,EmployeeID
	FROM Employees
)[emp]
PIVOT(
	COUNT(emp.EmployeeID)													--menjadi agregat function
		FOR emp.City IN([Kirkland],[London],[Redmond],[Seattle],[Tacome])	--menjadi kolom
) AS pvt;

select Title from Employees;


--ini contoh latihanya

select *
from 
(	select CONCAT( e.FirstName,' ', e.LastName) [nama lengkap],o.OrderID,c.City
		from Orders [o] 
		 join Employees [e] on o.EmployeeID=e.EmployeeID  
		 join Customers [c] on o.CustomerID = c.CustomerID
		 where e.Title = 'Sales Representative'
) [od]
PIVOT (
		COUNT ([od].OrderID)
			FOR od.city IN ([Berlin], [Warszawa],[London],[Paris],[Hamburg])
) AS PVT 
;