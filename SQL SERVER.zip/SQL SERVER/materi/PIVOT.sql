--PIPOT TABEL
SELECT E.Title, E.City, COUNT(*) [JUMLAH KARIYAWAN]
FROM Employees [E]
GROUP BY E.Title,E.City;



--BERIKUT CONTOH PIVOT menggunakan cte
WITH EemployessCity AS (
	SELECT Title,City,EmployeeID
	FROM Employees
)

SELECT * 
FROM EemployessCity [emp]
PIVOT(
	COUNT(emp.EmployeeID)
		FOR emp.City IN([Kirkland],[London],[Redmond],[Seattle],[Tacome])
) AS pvt;


--BERIKUT CONTOH PIVOT tapi menggunakan sub query
SELECT *
FROM (
	SELECT  Title,City,EmployeeID
	FROM Employees
)[emp]
PIVOT(
	COUNT(emp.EmployeeID)													--menjadi agregat function
		FOR emp.City IN([Kirkland],[London],[Redmond],[Seattle],[Tacome])	--menjadi kolom
) AS pvt;




--UNTUK PIVOT, DATANYA MINIMAL HARUS ADA 3, 2 UNTUK MENJADI BARIS DAN KOLOM DAN 1 UNTUK MENJADI PERHITUNGANYA
SELECT pvt.supplier AS [Category X, Supplier Y], [1], [2], [3], [4], [5], [6], [7], [8]
FROM (
	SELECT prod.SupplierID AS supplier, prod.CategoryID AS category, prod.UnitsInStock AS stock
	FROM dbo.Products AS prod
	)AS sumProd
	PIVOT(
	SUM(sumProd.stock) 
	FOR sumProd.category 
	IN ([1], [2], [3], [4], [5], [6], [7], [8])
	) AS pvt
ORDER BY pvt.supplier;




select distinct city from Customers;
