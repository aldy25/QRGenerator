/*
GENERATED ID
SALAH SATU yang sudah kita pakai dalah identity(seed,increment)
*/

/*
	ROWVERSION dan TIMESTAMP bersifat synonym, keduanya adalah tipe data yang merepresentasikan binary number yang di generate secara otomatis dan sifatnya unik 
	di database.

	Tapi pada pelajaran ini kita akan membahas ROWVERSION lebih banyak, karena timestamp sudah mulai deprecated.
*/
/*
	Pada SQL server nama timestamp sedikit missleading, walaupun dibilang timestamp, value dari timestamp tidak menyimpan informasi waktu sama sekali.
	Lain dengan timestamp ada Oracle DBMS.
*/

create database collage;
go 
use collage;
--rowversion/timestamp -> id yang dibuat sesuai urutan insert->nya, bisa di tempatkan di 2 table yang berbeda
CREATE TABLE ClassRoom(
	ID INT PRIMARY KEY IDENTITY(1,1),
	RoomNumber	 INT NOT NULL,
	[Subject] VARCHAR(50) NOT NULL,
	BeginTime TIME NOT NULL,
	EndTime TIME NOT NULL,
	RowNumber ROWVERSION NOT NULL, --HERE

);
CREATE TABLE PresentationRoom(
	ID INT PRIMARY KEY IDENTITY(1,1),
	RoomNumber INT NOT NULL,
	[Subject] VARCHAR(50) NOT NULL,
	BeginTime TIME NOT NULL,
	EndTime TIME NOT NULL,
	RowNumber ROWVERSION NOT NULL, --HERE
	
);
CREATE TABLE TutorialRoom(
	ID INT PRIMARY KEY IDENTITY(1,1),
	RoomNumber INT NOT NULL,
	[Subject] VARCHAR(50) NOT NULL,
	BeginTime TIME NOT NULL,
	EndTime TIME NOT NULL,
	TIMESTAMP,					--HERE
);

INSERT INTO ClassRoom(RoomNumber, [Subject], BeginTime, EndTime)
VALUES
(1, 'Java Fundamental', '09:30', '11:30'),
(2, 'C# Fundamental', '08:00', '10:00');
INSERT INTO PresentationRoom(RoomNumber, [Subject], BeginTime, EndTime)
VALUES
(3, 'Human Computer Interaction', '11:30', '13:30'),
(4, 'Database Fundamental', '10:00', '12:00');
INSERT INTO TutorialRoom(RoomNumber, [Subject], BeginTime, EndTime)
VALUES
(3, 'net', '11:30', '13:30'),
(4, 'php', '10:00', '12:00');

select * from ClassRoom
union
select * from PresentationRoom
union
select * from TutorialRoom
order by RoomNumber;

--global variable untuk memeriksa nilai timestamp yang terakhir dimasukan dari table ke table yaitu DBTS(DataBase Time Stamp)
SELECT  @@DBTS;

--ROW VERISON JUGA AKAN MELACAK  UPDATE
UPDATE ClassRoom
SET RoomNumber=255
WHERE ID=1;

/*
BERIKUT ADALAH SIMBOL GENERATE HEXADECIMAL
0, 1, 2, 3, 4, 5, 6, 7, 8, 9,  A,  B,  C,  D,  E,  F
1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,

*/

/*
UNIQUEIDENTIFIER : tipe data untuk 128 bit dengan karakter yang hexadecimal yang mengacak

*/

/*
	UNIQUEIDENTIFIER atau sering disebut juga dengan GUID (Global Unique Identifier) adalah system mengenerate nomor unik dari sebuah function.
	UNIQUEIDENTIFIER menggunakan 16 byte memory dan selalu men-generate kombinasi unik, bahkan antar database.

	UNIQUEIDENTIFIER biasa digunakan sebagai ID dan PK untuk sebuah table.
*/

 
--GUID bisa digenerate dari function NEWID()
SELECT NEWID();


CREATE TABLE Tutor(
	ID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
	[Name] VARCHAR(100) NOT NULL,
	BirthDate DATE NOT NULL,
	BirthPlace VARCHAR(50) NOT NULL,
	EmployeeStatus VARCHAR(50) NOT NULL
);

/*INSERT VALUE nya dengan menggunakan NEWID()*/
INSERT INTO dbo.Tutor([Name], BirthDate, BirthPlace, EmployeeStatus)
VALUES
('Andreas', '1988/11/27', 'Jakarta', 'Permanent'),
('Felicia', '1989/05/04', 'Bandung', 'Kontrak');


SELECT * FROM Tutor;

--Mengatur genratedID untuk IDENTITY
------------------------------------
--matiin identity otomatisnya
SET IDENTITY_INSERT TutorialRoom ON;
------------------------------------
INSERT INTO TutorialRoom(ID,RoomNumber, [Subject], BeginTime, EndTime)
VALUES
(100,3, 'net', '11:30', '13:30');
--nyalain identity otomatisnya
SET IDENTITY_INSERT TutorialRoom OFF;
------------------------------------
INSERT INTO TutorialRoom(RoomNumber, [Subject], BeginTime, EndTime)
VALUES
(3, 'net', '11:30', '13:30');

/*
	Ada beberapa cara untuk mendapatkan Identity Number yang di tambahkan secara otomatis oleh IDENTITY:

	1. SCOPE_IDENTITY(): mendapatkan identity terakhir yang diciptakan table, selama prosesnya masih berasal dari dalam batch.
	2. IDENT_CURRENT(): mendapatkan identity terakhir yang diciptakan table dari scope manapun atau pun user mana pun.
	3. @@IDENTITY: mendapatkan identity terakhir yang digenerate selama masih di dalam current connection, tidak perduli berbedaan scope/batch.
*/
INSERT INTO ClassRoom(RoomNumber, [Subject], BeginTime, EndTime)
VALUES
(1, 'Java Fundamental', '09:30', '11:30'),
(2, 'C# Fundamental', '08:00', '10:00');
SELECT SCOPE_IDENTITY() AS [scope identity]; --terakhir yang dimasukin berapa dalam satu batch
SELECT IDENT_CURRENT('ClassRoom') AS [ident current]; --spesifik table
SELECT @@IDENTITY AS [global identity]; --KONEKSINYA




