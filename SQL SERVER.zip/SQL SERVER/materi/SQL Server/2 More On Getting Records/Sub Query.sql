USE Northwind;

--Sub-Query : Query dalam query, mirip seperti Bab di dalam Bab (sub-bab)

SELECT (SELECT 1)

SELECT (SELECT * FROM Employees)

/*
	1. Single Value (Scalar)
	2. Multi Value (List / Vector)
	3. Table Value
*/

--Single Value	1x1
SELECT 'test'

--Multi Value	nx1		n>1
SELECT City FROM Employees

--Table Value	nxm		m>1
SELECT * FROM Employees 
WHERE EmployeeID = 1

--Informasi harga berdasarkan nama produk, dan nama perusahan
SELECT ProductName, CompanyName, UnitPrice
FROM Products pro
	JOIN Suppliers sup ON pro.SupplierID = sup.SupplierID
WHERE UnitPrice > 54.0066
ORDER BY UnitPrice

--Kategori dengan harga rata-rata tertinggi
SELECT TOP 1 AVG(UnitPrice) [Harga Rata-rata]
FROM Products
GROUP BY CategoryID
ORDER BY [Harga Rata-rata] DESC



SELECT ProductName, CompanyName, UnitPrice
FROM Products pro
	JOIN Suppliers sup ON pro.SupplierID = sup.SupplierID
WHERE UnitPrice > (SELECT TOP 1 AVG(UnitPrice) [Harga Rata-rata]
					FROM Products
					GROUP BY CategoryID
					ORDER BY [Harga Rata-rata] DESC
					)
ORDER BY UnitPrice

--Sub-query harus berfungsi secara efektif dan tidak menggunakan ORDER BY
--secara asal.
SELECT ProductName, CompanyName, UnitPrice
FROM Products pro
	JOIN Suppliers sup ON pro.SupplierID = sup.SupplierID
WHERE UnitPrice > (SELECT AVG(UnitPrice) [Harga Rata-rata]
					FROM Products
					--ORDER BY [Harga Rata-rata]
					)
ORDER BY UnitPrice

--MULTI VALUE
SELECT *
FROM Customers
WHERE City IN (SELECT DISTINCT City FROM Employees)

--TABLE VALUE
SELECT emp.*
FROM (SELECT * FROM Employees) AS emp

--TABLE VALUE
SELECT cat.CategoryName, [Harga Rata-rata]
FROM (SELECT CategoryID, AVG(UnitPrice) [Harga Rata-rata]
		FROM Products
		GROUP BY CategoryID
		) AS [Average Product Price By Category]
	JOIN Categories cat 
		ON [Average Product Price By Category].CategoryID = cat.CategoryID;

/*
	tabel yang digunakan untuk sub-query (derived table):

	1. Table-value sub-query harus memiliki alias
	2. Table-value sub-query untuk kolomnya harus memiliki alias
	3. Sub-query harus menggunakan ORDER BY kalau berhubungan sama TOP / OFFSET &FETCH
*/

--EXISTS (ada)
--kalau misalkan tidak ada record 1 pun yang cocok, maka jangan di tampilkan.

SELECT * FROM Employees
WHERE EXISTS (SELECT * FROM Orders WHERE OrderID = 1)

SELECT * FROM Employees
WHERE NOT EXISTS (SELECT * FROM Orders WHERE OrderID = 1)

--tidak ada region yang sama antara supplier dan employees
SELECT * 
FROM Suppliers sup
WHERE EXISTS (SELECT * FROM Employees emp
				WHERE emp.Region = sup.Region)
--ada city yang sama antara supplier dan employees. maka tunjukan yang sama tersebut
SELECT * 
FROM Suppliers sup
WHERE EXISTS (SELECT * FROM Employees emp
				WHERE emp.City = sup.City)

--hasil diatas sama persis dengan query dibawah ini
SELECT * 
FROM Suppliers sup
WHERE sup.City IN (SELECT DISTINCT City FROM Employees)