--GROUP BY

--AGGREGATE FUNCTION
--nilai terbesar
SELECT MAX(EmployeeID)--9
FROM Employees emp		--9

--nilai terkecil
SELECT MIN(EmployeeID)--1
FROM Employees emp		--9

--nilai rata-rata (MEAN)
SELECT AVG(EmployeeID)--5
FROM Employees emp		--9

--hitung seluruh record
SELECT COUNT(*)--9
FROM Employees emp		--9

SELECT SUM(emp.EmployeeID)
FROM Employees emp


SELECT MAX(EmployeeID), AVG(EmployeeID), MIN(EmployeeID), 
		COUNT(EmployeeID), SUM(EmployeeID)
FROM Employees emp		--9

--Employees, Products, Categories

SELECT * FROM Categories

SELECT ProductID, CategoryID
FROM Products

SELECT pro.CategoryID,								--8
		AVG(UnitPrice) [Average Unit Price],		--8
		MAX(UnitPrice) [Maximum Price],				--8
		COUNT(ProductID) [Jumlah Produk]
FROM Products pro			-- 77
GROUP BY pro.CategoryID		-- 8

SELECT * FROM Employees

SELECT TitleOfCourtesy, City,
		COUNT(*) [Jumlah Karyawan]
FROM Employees								--9
GROUP BY TitleOfCourtesy, City				--6
HAVING TitleOfCourtesy = 'Ms.'				--3


SELECT TitleOfCourtesy, City,
		COUNT(*) [Jumlah Karyawan]
FROM Employees								--9
WHERE TitleOfCourtesy = 'Ms.'				--4
GROUP BY TitleOfCourtesy, City				--3


SELECT City,
		COUNT(*) [Jumlah Karyawan]
FROM Employees								--9
WHERE TitleOfCourtesy = 'Ms.'				--4
GROUP BY City				--3
HAVING COUNT(*) > 1							--1


SELECT emp.TitleOfCourtesy, emp.City,
		COUNT(*) [Jumlah Karyawan]			
FROM Employees emp								--9
GROUP BY emp.TitleOfCourtesy, emp.City			--6
HAVING COUNT(*) > 1								--2

SELECT Region, COUNT(*) [Jumlah Karyawan]
FROM Employees
WHERE Region IS NOT NULL
GROUP BY Region



SELECT TitleOfCourtesy, City,
		COUNT(*) [Jumlah Karyawan]
FROM Employees								--9
GROUP BY TitleOfCourtesy, City				--6
HAVING TitleOfCourtesy = 'Ms.' AND COUNT(*) > 1				--3

--Harga rata-rata produk berdasarkan kategori yang produknya diatas $10
SELECT CategoryID, AVG(UnitPrice) [Harga rata-rata]
FROM Products
WHERE UnitPrice >= 10	--66
GROUP BY CategoryID		--8
HAVING AVG(UnitPrice) > 30
ORDER BY AVG(UnitPrice) DESC
/*
		SQL :
		FROM -> WHERE -> GROUP BY -> HAVING -> SELECT -> ORDER BY
*/

SELECT CategoryID, AVG(UnitPrice) [Harga rata-rata], MIN(UnitPrice) [Jumlah]
FROM Products
WHERE UnitPrice > 3	--66
GROUP BY CategoryID		--8
HAVING AVG(UnitPrice) > 30
ORDER BY [Harga rata-rata] DESC, [Jumlah];

SELECT * 
FROM Products pro
ORDER BY CategoryID DESC, ReorderLevel ASC, ProductID DESC;

-- khusus untuk TOP : order by sangat mempengaruhi data yang akan di ambil

SELECT TOP 5 *
FROM Products pro
ORDER BY CategoryID DESC, ReorderLevel ASC, ProductID DESC;

SELECT TOP 50 PERCENT *
FROM Products pro
ORDER BY CategoryID DESC, ReorderLevel ASC, ProductID DESC;

SELECT TOP 5 *
FROM Products
ORDER BY ProductID DESC

SELECT *
FROM Products
ORDER BY ProductID
OFFSET 10 ROWS				--skip 10 baris
FETCH FIRST 5 ROWS ONLY		--ambil 5 baris pertama

SELECT *
FROM Products
ORDER BY ProductID
OFFSET 10 ROWS				--skip 10 baris