SELECT emp.EmployeeID, emp.FirstName
FROM Employees AS emp;	--9 record / row
--WHERE

SELECT emp.EmployeeID, emp.FirstName
FROM Employees AS emp			--9 records / rows
WHERE emp.EmployeeID > 4;		--5 records / rows

/*
	jika kondisinya benar, maka recordnya akan diambil oleh SELECT
	record 1 (EmployeeID 1): 1 > 4? tidak.
	record 2 (EmployeeID 2): 2 > 4? tidak.
	record 3 (EmployeeID 3): 3 > 4? tidak.
	record 4 (EmployeeID 4): 4 > 4? tidak.
	record 5 (EmployeeID 5): 5 > 4? ya.
	record 6 (EmployeeID 6): 6 > 4? ya.
	record 7 (EmployeeID 7): 7 > 4? ya.
	record 8 (EmployeeID 8): 8 > 4? ya.
	record 9 (EmployeeID 9): 9 > 4? ya.
*/

-- COMPARISON:     =, !=, >, <, >=, <=
-- |>esar
-- |<ecil

SELECT * 
FROM Employees		--9
WHERE 1 = 1
/*
	record 1 : 1 = 1? ya.
	record 2 : 1 = 1? ya.
	record 3 : 1 = 1? ya.
	record 4 : 1 = 1? ya.
	record 5 : 1 = 1? ya.
	record 6 : 1 = 1? ya.
	record 7 : 1 = 1? ya.
	record 8 : 1 = 1? ya.
	record 9 : 1 = 1? ya.
*/

SELECT * 
FROM Products pro
WHERE pro.CategoryID >= 1

-- coba cari produk yang kategori ID-nya diantara 4 DAN 7 (4,5,6,7)
-- AND (dan), OR (atau)

SELECT * 
FROM Products pro	--77
WHERE pro.CategoryID = 4 AND pro.CategoryID <= 7 --28

-- ProductID = 1, CategoryID = 1.... 1 = 4 (salah) AND 1 <= 7 (bener)

/*
	KALO AND, dua duanya harus benar (maka benar)
	KALO OR, dua duanya harus salah (maka salah)
*/

SELECT * 
FROM Products pro	--77
WHERE pro.CategoryID = 4 AND pro.CategoryID <= 7
	AND pro.UnitsInStock > 100

SELECT * 
FROM Products pro	--77
WHERE pro.CategoryID BETWEEN 4 AND 7

SELECT * 
FROM Products pro	--77
WHERE pro.CategoryID NOT BETWEEN 4 AND 7

--yyyy-MM-dd
SELECT * FROM Employees
WHERE BirthDate BETWEEN '1937-09-20' AND '1958-01-08'

SELECT * 
FROM Employees
WHERE City = 'Seattle' OR City = 'London'

SELECT * 
FROM Employees
WHERE City IN ('Seattle','London')

SELECT * FROM Employees
WHERE BirthDate IN('1948-12-08')

SELECT * FROM Employees
WHERE EmployeeID IN(1,5,8)

SELECT * FROM Employees
WHERE EmployeeID < 3 OR EmployeeID > 7

SELECT * FROM Employees
WHERE EmployeeID NOT BETWEEN 3 AND 7

SELECT * FROM Employees
WHERE EmployeeID NOT IN(2)

SELECT * FROM Employees
WHERE LastName = 'King'

--wildcard like salah satunya '%'
SELECT * FROM Employees
WHERE LastName LIKE 'K%'

SELECT * FROM Employees
WHERE LastName LIKE '%K'

SELECT * FROM Employees
WHERE LastName LIKE '%K%'

SELECT * FROM Employees
WHERE LastName NOT LIKE '%K%'

SELECT * FROM Customers
WHERE ContactTitle IN('Owner, Sales Representative')

SELECT * FROM Customers
WHERE ContactTitle IN('Owner', 'Sales Representative')

--NULL ?
SELECT	1 [DATA], 
		'' [DATA KEDUA], 
		NULL [DATA KETIGA]

SELECT * FROM Employees

SELECT Employees.EmployeeID, 1, 'Tidak Terlambat'
FROM Employees			--9

--tidak dapat membandingkan sesuatu yang ada dengan yang tidak ada.
SELECT * FROM Employees
WHERE Region = NULL

SELECT * FROM Employees
WHERE Region IS NULL

SELECT * FROM Employees
WHERE Region IS NOT NULL