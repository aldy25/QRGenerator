USE Northwind;

--melihat seluruh employees dengan asterik (*)
SELECT * FROM Employees;

/*
	select query bisa tidak di baris yang sama
	asalkan strukturnya benar.
*/
SELECT EmployeeID 
FROM Employees;

/*
	SQL (Structured Query Language)

	Tabel (METADATA), 
	Kolom (METADATA)

	Isi dari tabel (DATA)
	kumpulan dari data (RECORD)

	SELECT kolom
	FROM tabel
*/

--alias untuk tabel
SELECT Categories.CategoryID, Categories.CategoryName
FROM Categories

SELECT ca.CategoryID, ca.CategoryName
FROM Categories AS ca

--untuk kolom digantikan namanya pada saat query dijalankan
SELECT ca.CategoryID AS [ID Kategori], ca.CategoryName [Nama Kategori]
FROM Categories [ca]

--menggabungkan lebih dari satu data menjadi satu data.
SELECT CONCAT(emp.FirstName, ' ', emp.LastName) [FullName]
FROM Employees AS emp

SELECT CONCAT_WS(' ', emp.FirstName, emp.LastName, emp.BirthDate) [FullName]
FROM Employees AS emp

SELECT * FROM Categories --8

SELECT * FROM Products	--77

SELECT ca.CategoryID, 
		pr.CategoryID
FROM Categories AS ca, 
		Products AS pr	-- 8 * 77 = 616