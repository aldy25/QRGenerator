USE GirlFlower;

/*
	Demo database ini digunakan untuk memahami join.
	Scenarionya : perempuan membeli bunga dari toko.
*/

SELECT * FROM Girl;
SELECT * FROM Store;
SELECT * FROM Flower;

--tabel ini akan memberitahu relasi antara tabel Girl (pembeli) dan Store (penjual)
SELECT * FROM Flower;

--Secara otomatis akan mengabaikan yang 1 = NULL
SELECT flo.[Name] AS [Bunga], grl.[Name] AS [Pembeli]
FROM Flower AS flo
	JOIN Girl AS grl ON flo.GirlID = grl.ID

--LEFT / RIGHT JOIN akan mengambil NULL yang sebelumnya tidak termasuk
SELECT flo.[Name] AS [Bunga], grl.[Name] AS [Pembeli]
FROM Flower AS flo 
	LEFT JOIN Girl AS grl ON  grl.ID = flo.GirlID

SELECT flo.[Name] AS [Bunga], grl.[Name] AS [Pembeli]
FROM Flower AS flo 
	RIGHT JOIN Girl AS grl ON  grl.ID = flo.GirlID

SELECT flo.[Name] AS [Bunga], grl.[Name] AS [Pembeli]
FROM Flower AS flo 
	FULL JOIN Girl AS grl ON  grl.ID = flo.GirlID

/*
	cara menggabungkan tabel pada SQL Server:
	JOIN / INNER JOIN
	LEFT JOIN / LEFT OUTER JOIN
	RIGHT JOIN / RIGHT OUTER JOIN
	FULL JOIN / FULL OUTER JOIN
*/
SELECT flo.ID [ID Flower], grl.ID [ID Girl], flo.[Name] AS [Bunga], grl.[Name] AS [Pembeli]
FROM Flower AS flo
	JOIN Girl AS grl ON flo.GirlID = grl.ID


SELECT flo.[Name] AS [Bunga], grl.[Name] AS [Pembeli], st.[Name]
FROM Flower AS flo
	JOIN Girl AS grl ON flo.GirlID = grl.ID
	LEFT JOIN Store AS st ON flo.StoreID = st.ID


--UNION, UNION ALL, INTERSECT, DAN EXCEPT
USE Northwind;

--Mengambil seluruh data yang unik menggunakan DISTINCT
SELECT DISTINCT City FROM Employees;


--UNION DAN UNION ALL
SELECT City FROM Employees		--9 kota
UNION									--71 kota yang unik
SELECT City FROM Customers;		--91 kota

SELECT City FROM Employees		--9 kota
UNION ALL									--100 kota (tidak memperdulikan unik)
SELECT City FROM Customers;		--91 kota

SELECT FirstName [Kumpulan Nama] FROM Employees
UNION
SELECT LastName FROM Employees

SELECT Customers.ContactName [Daftar Nama], Address
FROM Customers
UNION
SELECT CONCAT(FirstName, ' ', LastName), Address
FROM Employees
UNION
SELECT Suppliers.ContactName, Address
FROM Suppliers
ORDER BY [Daftar Nama] DESC

--INTERSECT
SELECT * FROM Employees WHERE City IN('Kirkland', 'London', 'Seattle')
SELECT * FROM Customers WHERE City IN('Kirkland', 'London', 'Seattle')

--ada di employee dan ada di customer
SELECT City FROM Employees
INTERSECT
SELECT City FROM Customers

--EXCEPT
--di Employees ada namun di Customers tidak ada
SELECT City FROM Employees
EXCEPT
SELECT City FROM Customers

--di Customers ada namun di Employees tidak ada
SELECT City FROM Customers
EXCEPT
SELECT City FROM Employees

--CONTOH ERROR
SELECT Customers.ContactName [Daftar Nama], Address
FROM Customers
ORDER BY ContactName				--akan error karena order by tidak efektif
UNION
SELECT CONCAT(FirstName, ' ', LastName), Address
FROM Employees
UNION
SELECT Suppliers.ContactName, Address
FROM Suppliers
ORDER BY [Daftar Nama] DESC