/* 
	View adalah table virtual yang dihasilkan dari sebuah query yang diberi nama dan di simpan dalam catalog view, 
	yang nantinya table value hasil querynya bisa digunakan nanti oleh query lain.
	
	Beberapa sifat-sifat view:
	1. 1 view cuma terdiri dari satu query.
	2. Saat ingin membuat view, tidak boleh ada statement lain di dalam query.
	3. View digunakan untuk kebutuhan re-usable query.
	4. Di database, view tidak menyimpan hasil, tapi hanya menyimpan querynya saja.
*/

USE  Northwind;
GO
CREATE OR ALTER VIEW [Order With Product Quabtity] AS 
SELECT ord.OrderID,ord.CustomerID,ord.OrderDate,ord.ShippedDate,
		COUNT(orDet.OrderID) [ProductInOrder]
FROM Orders [ord]
JOIN [Order Details] [orDet] ON ord.OrderID=orDet.OrderID
GROUP BY ord.OrderID,ord.CustomerID,ord.OrderDate,ord.ShippedDate
GO
SELECT * FROM [Order With Product Quabtity];
GO
ALTER VIEW [Order With Product Quabtity] AS
SELECT ord.OrderID,ord.CustomerID,ord.OrderDate,ord.ShippedDate,
		COUNT(orDet.OrderID) [Quantity Product]
FROM Orders [ord]
JOIN [Order Details] [orDet] ON ord.OrderID=orDet.OrderID
GROUP BY ord.OrderID,ord.CustomerID,ord.OrderDate,ord.ShippedDate
GO
DROP VIEW [Order With Product Quabtity];

--mencoba view join  dengan view
SELECT inc.CustomerName, ordp.ProductInOrder
FROM [Order With Product Quabtity] [ordp]
JOIN Invoices [inc] ON INC.CustomerID=ordp.CustomerID;


