/*

CRUD -> CREATE->READ->UPDATE->DELETE;
DML (Data manipulation language)

insert ->menyimpan
update -> mengubah data yang sudah ada
delete -> menghapus data yang sudah ada

*/

USE KULIAH;

--menyimpan data yang sudah ada sesuai dengan urutan kolomnya
INSERT INTO Mahasiswa VALUES
('09/2023/0001','OTTO','Tirtayasa','Akbar','L','2000-01-01','085266935709',
'OTTO@INDOCYBER.ID','Jl. Daan Mogot',GETDATE());


--MENYIMPAN DATA COLUMN DENGAN NAMA COLUMNYA .(kalau default otomatis akan terisi tanpa harus disebut kolomnya)
INSERT INTO Mahasiswa(NamaDepan,NamaTengah,NamaBelakang,JenisKelamin,TanggalLahir,NomorTelefon,Email,Alamat,MahasiswaID) 
VALUES
('ANI','Tirtayasa','Akbar','L','2000-01-01','085266935709',
'ANI@INDOCYBER.ID','Jl. Daan Mogot','AOO2');
SELECT * FROM Mahasiswa;

--UPDATE MAHASISWA
UPDATE Mahasiswa 
SET TanggalMendaftar=GETDATE()
WHERE MahasiswaID='09/2023/0001';

