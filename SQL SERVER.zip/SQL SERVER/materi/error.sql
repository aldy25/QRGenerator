/*
	syntak error	: Error yang disebabkan oleh syntak yang salah (seperti salah ketik)
	runtime error	: pada saat dijakankan ada sebuah error dan biasanya disebabkan oleh kurang pahamnya bahasa pemrogramanya
	logical error	: pada saat dijalankan tidak ada error, namun tidak sesuai dengan yang kita inginkan sering disebut juga sebagai
					  bug . bisa jadi penyebabnya karena kita ataupun si bahasa pemrogramanya atau faktor yang tidak dapat ditebak
*/

--contoh syntak error
selct * from employees;

--contoh runtime error
DECLARE @contoh AS VARCHAR(20) ='ABC'
SELECT PARSE (@contoh AS int);

use master;
go
/*
	TRY CATCH digunakan untuk menangani yang memungkinkan bisa error
*/
DECLARE @jumlahMinuman int = 10;
DECLARE @jumlahOrang int =0;

--kalo misal ada error, dan tau mau diapain.. gunakan TRY CATCH
BEGIN TRY
	DECLARE @hasilbagi int =@jumlahMinuman/@jumlahOrang
	PRINT CONCAT_WS(' ','Masing masing mendapatkan', @hasilbagi,'Minuman');
END TRY
BEGIN CATCH
	PRINT 'Jumlah orang tidak boleh nol'
	SELECT	ERROR_NUMBER() AS ErrorNumber, --Function yang digunakan untuk mendapatkan error number dari suatu percobaan yang dilakukan.
			ERROR_SEVERITY() AS ErrorSeverity, --Function yang digunakan untuk mendapatkan tingkat keparahan error. check di https://blog.sqlauthority.com/2007/04/25/sql-server-error-messages-sysmessages-error-severity-level/
			ERROR_STATE() AS ErrorState, 
			ERROR_PROCEDURE() AS ErrorProcedure, --Untuk mengembalikan nama SP (Store Procedure) dimana error ini terjadi. 
			ERROR_LINE() AS ErrorLine,  --Lokasi line tempat error terjadi.
			ERROR_MESSAGE() AS ErrorMessage; 
END CATCH

/*Statement GOTO digunakan agar eksekusi sebuah line bisa jump ke statement lain-lain yang diberi nama.*/
DECLARE @pressedButton INT = 2;
IF @pressedButton = 1 GOTO DrinkOne;
IF @pressedButton = 2 GOTO DrinkTwo;
IF @pressedButton = 3 GOTO DrinkThree;
IF @pressedButton = 4 GOTO DrinkFour;

DrinkOne:
	PRINT 'Coca-cola';
	GOTO ExtraOne;

DrinkTwo:
	PRINT 'Sprite';
	GOTO ExtraOne;

DrinkThree:
	PRINT 'Es Jelly';
	GOTO ExtraTwo;

DrinkFour:
	PRINT 'Fanta';
	GOTO ExtraOne;

ExtraOne:
	PRINT 'Sedotan';

ExtraTwo:
	PRINT 'Sendok';

/*
	Notice kalau sendok masih dijalankan, itulah kelemahan dari GOTO, karena seluruh proses setelahnya masih akan dijalankan.
	Seluruh statement tetap akan dijalankan seperti selayaknya seluruh code dijalan-kan baris-perbaris.

	Sendok masih di jalankan , sedangkan Es Jelly dan Fanta di skip karena statementnya GO TO ExtraOne, yaitu sedotan, tetapi karena
	Sendok berada setelah sedotan, maka akan tetap di jalankan.

	Trivia: GOTO ini persis seperti GOTO pada programming language seperti java, C# dan C++
*/
/*
JANGAN GUNAKAN GO TO LAGI
*/