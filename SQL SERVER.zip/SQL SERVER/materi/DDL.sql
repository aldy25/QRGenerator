-- DDL (DATA DEFINITON LANGUAGE) -> MEMBUAT STRUKTUR DATABASE (DATABASE, TABEL, KOLOM, CONSTRAIN)

/*
	1. MEMBUAT		: CREATE
	2. MENGUBAH		: ALTER
	3. MENGHAPUS	: DROP
*/

CREATE DATABASE College;
GO   --------------------------->MENJALANKAN SEMUA KODE YANG DI BAWAH

--gunakan database
use northwind;

--ubah nama database
ALTER DATABASE College MODIFY NAME = Kuliah; -- mengubah database
 -- menghapus nama database

CREATE DATABASE Kuliah;
--BACKUP DATABASE College TO DISK ='C:\Users\1903\Documents\materi\College.bak'; -- MENGEBACKUP DATABASE

USE master
--menghapus database
DROP DATABASE Kuliah;

CREATE DATABASE Kuliah
GO
USE Kuliah;
CREATE TABLE Mahasiswa(

MahasiswaID VARCHAR(20)
);
DROP TABLE Mahasiswa

-------membuat table
CREATE TABLE Mahasiswa (
	MahasiswaID VARCHAR (20),
	NamaDepan varchar (50),
	NamaTengah VARCHAR(50),
	NamaBelakang VARCHAR(50),
	JenisKelamin VARCHAR(1),
	TanggalLahir date,
	NomorTelefon VARCHAR(15),
	Email VARCHAR(100),
	Alamat VARCHAR(500),
	TanggalMendaftar datetime
);

--tambah column dengan cara mengubah struktur tabel
ALTER TABLE Mahasiswa
ADD Penjurusan VARCHAR(100);

--ubah kolom dengan cara mengubah struktur tabel
ALTER TABLE Mahasiswa
ALTER COLUMN NomorTelefon varchar(20);

--hapus sebuah column yang ada dengan mengubah struktur tabel
ALTER TABLE Mahasiswa 
	DROP COLUMN Penjurusan

-- Mngecek scema database
SELECT * FROM INFORMATION_SCHEMA.COLUMNS;

/*
Constrain adalah hal yang digunakan untuk memberi batasan-batasan dan kemampuan setiap column di dalam table
-harus ada kolomnya untuk dipakai ikatan
- tipenya :
	1. not null : agar dia wajib di isi / agar dia tidak null
	2. unique	: agar nilainya satu-satunya yang ada di kolom tersebut
	3. check	: jika ingin memasukan nilai, harus diperiksa dulu jika memenuhi syarat
	4. default	: jika tidak memasukan nilai apapun, maka nilai default yang akan dimasukan

*/

drop table Mahasiswa

CREATE TABLE Mahasiswa (
	MahasiswaID VARCHAR (20) UNIQUE NOT NULL,
	NamaDepan varchar (50) NOT NULL,
	NamaTengah VARCHAR(50),
	NamaBelakang VARCHAR(50),
	JenisKelamin VARCHAR(1) NOT NULL CHECK(JenisKelamin ='L' OR JenisKelamin='P'),
	TanggalLahir DATE NOT NULL,
	NomorTelefon VARCHAR(15) NOT NULL,
	Email VARCHAR(100) NOT NULL UNIQUE CHECK(Email Like '%@%'),
	Alamat VARCHAR(500) NOT NULL,
	TanggalMendaftar datetime NOT NULL DEFAULT(GETDATE())
);

--DATA MANIPULATON LANGUAGE (DML)

--MEMASUKAN RECORD BARU KE DALAM TABEL
INSERT INTO  Mahasiswa(MahasiswaID,NamaDepan,NamaBelakang,JenisKelamin,TanggalLahir,NomorTelefon,Email,Alamat)
	VALUES('A001','ALDY','NIFRATAMA','L','2001-04-25','085266935709','ALDYNIFRATAMA25@GMAIL.COM','SUKADANA');

GO 
SELECT * FROM Mahasiswa;
--MENGUBAH RECORD YANG ADA DI DALAM TABEL
UPDATE Mahasiswa 
SET MahasiswaID ='AN001',NamaDepan ='TES'
WHERE MahasiswaID='A001'
GO
--MENGHAPUS RECORD SESUAI DENGAN FILTER WHERE
DELETE Mahasiswa
WHERE MahasiswaID ='AN001'
GO
SELECT * FROM Mahasiswa

/*
	KEYS :
	1. UNIQUE KEY	: 
	2. PRIMARY KEY	: Identifikasi sebuah record, hanya boleh dalam 1 record
	3. FOREIGN KEY	: Nilai dalam sebuah kolom yang ada di record, dari nilai record tabel lain
*/
USE KULIAH
drop table Mahasiswa
GO
CREATE TABLE Mahasiswa (
	MahasiswaID VARCHAR (20) PRIMARY KEY,
	NamaDepan varchar (50) NOT NULL,
	NamaTengah VARCHAR(50),
	NamaBelakang VARCHAR(50),
	JenisKelamin VARCHAR(1) NOT NULL CHECK(JenisKelamin ='L' OR JenisKelamin='P'),
	TanggalLahir DATE NOT NULL,
	NomorTelefon VARCHAR(15) NOT NULL,
	Email VARCHAR(100) NOT NULL UNIQUE CHECK(Email Like '%@%'),
	Alamat VARCHAR(500) NOT NULL,
	TanggalMendaftar datetime NOT NULL DEFAULT(GETDATE())
);
--CONTOH QY=UERY UNTUK MENGGUNAKAN AUTOINCREMENTEL MENGGUNAKAN FUNGSI IDENTITY YANG DIMANA PARAMTER PERTAMA ADALAH ANGKA MULAINYA 
--DAN PARAMETER KE 2 NYA  ADALAH JUMLAH ANGKA YANG DI LONCATI -> IDENTITY(n,m)

CREATE TABLE Soal1(
	SoalID INT PRIMARY KEY IDENTITY(1,1),
	Deskripsi VARCHAR(200),
	JawabanBenar VARCHAR(50)
)

GO
INSERT INTO Soal1(Deskripsi,JawabanBenar)
	VALUES('LOREM IPSUM DOLOR','Berhasil');

GO
SELECT * FROM Soal1;
GO
DROP TABLE Soal1;



--FOREIGN KEY
--fungsi references digunakan untuk menghubungkan ke tabel index
CREATE TABLE KamarAsrama(
	KamarAsramaID VARCHAR(3) PRIMARY KEY,
	Harga money NOT NULL,
	AdaKamarMandi bit NOT NULL DEFAULT 1,
	DimensiKamar VARCHAR(20) NOT NULL,
	AdaAC bit NOT NULL DEFAULT(1),
	Deskripsi VARCHAR(MAX) NOT NULL,
	MahasiswaID VARCHAR(20) FOREIGN KEY REFERENCES Mahasiswa(MahasiswaID)
)
GO
SELECT * FROM KamarAsrama;
--INI UNTUK INSERT YANG DITENTUKAN SENDIRI COLUMNNYA
INSERT INTO KamarAsrama(KamarAsramaID,Harga,AdaKamarMandi,DimensiKamar,AdaAC,Deskripsi)
VALUES('101',1500000,1,'3.5 X 3',1,'Kamar untuk anak');

GO
UPDATE KamarAsrama
	SET MahasiswaID ='A001'
WHERE KamarAsramaID='101';

SELECT KamarAsramaID [Kode Kamar] ,CONCAT(M.NamaDepan,' ',M.NamaBelakang) [Mahasiswa]
	FROM KamarAsrama [KA]
	JOIN Mahasiswa [M] ON KA.MahasiswaID=M.MahasiswaID;

------------------------------------------------------------------------------------------
DROP TABLE KamarAsrama; ----TABLE KamarAsrama tidak bisa di hapus karena memiliki ketergantungan ke tabel mahasiswa atau tabel lain
-----------------------------------------------------------------------------------------

--composite key (primary key yang digabungkan dari 2 kolom yang berbeda), tapi primary key hanya boleh ada 1 dalam 1 tabel

CREATE TABLE Matakuliah(
	Jurusan VARCHAR(50) NOT NULL ,
	Nama VARCHAR(50) NOT NULL,
	Deskripsi VARCHAR(500),
	SKS INT CONSTRAINT [CK_SKS] CHECK(SKS BETWEEN 1 AND 4), --CONSTRAINT DIGUNAKAN UNTUK MENGUBAH NAMA CONSTRAINT DEFAULT
	Tingkat VARCHAR(2) NOT NULL CONSTRAINT [Matakuliah_Tingkat] DEFAULT 'S1',
	PRIMARY KEY(Jurusan,Nama)--PRIMARY KEY NYA YAITU JURUSAN DAN NAMA KARENA MENGGUNAKAN COMPOSITE NAME 
)
GO
INSERT INTO Matakuliah(Jurusan,Nama,Deskripsi,SKS)
	   VALUES('Sistem Komputer','Jaringan','Biar Bisa Internetan','3');
GO
SELECT * FROM Matakuliah;
GO
CREATE TABLE Topik (
	ID INT PRIMARY KEY,
	JurusanMatakuliah VARCHAR (50) NOT NULL,
	NamaMatakuliah VARCHAR(50) NOT NULL,
	Deskripsi VARCHAR(500),
	FOREIGN KEY(JurusanMatakuliah,NamaMatakuliah) REFERENCES Matakuliah(Jurusan,Nama)
)

GO

--gagal karena tidak ada kombinasi sistem informasi  dan jaringan
INSERT INTO Topik(ID,JurusanMatakuliah,NamaMatakuliah,Deskripsi)
	VALUES(1,'Sistem Informasi','Jaringan','Kelas Pertama')

--berhasil karena ada kombinasinya
INSERT INTO Topik(ID,JurusanMatakuliah,NamaMatakuliah,Deskripsi)
	VALUES(1,'Sistem Komputer','Jaringan','Kelas Pertama')
GO
SELECT * FROM Topik;


/*
DML (Data manipulation language)

insert ->menyimpan
update -> mengubah data yang sudah ada
delete -> menghapus data yang sudah ada

*/

USE KULIAH;

--menyimpan data yang sudah ada sesuai dengan urutan kolomnya
INSERT INTO Mahasiswa VALUES
('09/2023/0001','OTTO','Tirtayasa','Akbar','L','2000-01-01','085266935709',
'OTTO@INDOCYBER.ID','Jl. Daan Mogot',GETDATE());
SELECT * FROM Mahasiswa;




