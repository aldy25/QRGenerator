/*
	ISNULL() adalah fungsi yang digunakan untuk mengganti null dari sebuah column menjadi sesuatu yang lain.
	COALESCE() adalah untuk melakukan-nya ISNULL sekali banyak.
	NULLIF digunakan untuk mengembalikan null apabila 2 value di dalam parameters sama, apabila tidak sama, 
	maka parameter pertama akan digunakan.
*/
use Northwind
go
--contoh isnull()
SELECT ISNULL(Region,'No Region')
FROM Employees;

--contoh COALESCE()
SELECT COALESCE(HomePage,Region,'No Way To Contact')
FROM Suppliers;

--contoh  NULLIF()
SELECT CustomerID,CompanyName, NULLIF(ContactName,'Maria Anders') [Contac Name]
FROM Customers;

SELECT ProductName,UnitPrice,UnitsInStock,
		(UnitPrice/NULLIF(UnitsInStock,0)) [Unit per Price]
FROM Products;