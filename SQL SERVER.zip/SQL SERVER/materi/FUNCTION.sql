
/*
	Function adalah sederetan perintah SQL yang digunakan untuk mengerjakan spesifik task, tetapi perbedaanya dengan View adalah
	function bisa menerima parameter (input), me-return value (mengembalikan hasil /outputnya).

	Dilihat dari asal-usulnya, function bisa dibedakan menjadi 2 macam:
	1. SQL Server Built In Function: adalah function-function yang sudah disediakan oleh Microsoft SQL Server sendiri.
	2. User Defined Function: adalah Function yang dibuat oleh developer sendiri, bukan function yang sifatnya built-in dari sql server.
*/

/*
	Untuk membuat User-Defined Function, gunakan syntax seperti di bawah ini:

	CREATE FUNCTION digunakan untuk membuat function dan parameters.
	RETURNS DATATYPE digunakan untuk menyatakan tipe data output/hasil/return daripada function tersebut.
	Penulisan Parameter ditandai dengan () atau parameter bracket. Parameter adalah format input yang dimiliki oleh function, 
	dimana penulisannya sama seperti deklarasi variable.

	Note: untuk membuat user defined function, function block harus satu-satunya berada di dalam batch.
*/
/*
	- fungsi gunanya untuk menyimpan sebuah syntax / query
	- bisa menerima input atau parameter
	- memproses input tersebut secara sesuai
	- bisa memberi input
*/


CREATE FUNCTION Penjumlahan(@angka1 int, @angka2 int)
RETURNS INT AS
BEGIN
	RETURN @angka1 + @angka2
END;
go
SELECT dbo.Penjumlahan(5, 4) AS Hasil;
PRINT dbo.Penjumlahan(5,4);
GO

CREATE FUNCTION Perkenalan(
			@namaDepan varchar(50),
			@namaTengah varchar(50),
			@namaBelakang varchar(50)=NULL
)
RETURNS varchar(1000) AS
BEGIN
	DECLARE @HASIL varchar(max)
		IF (@namaBelakang IS NULL)
			BEGIN 
				SET @HASIL= CONCAT_WS(' ',@namaDepan,@namaTengah)
			END
		ELSE
			BEGIN
				SET @HASIL= 	CONCAT_WS(' ',@namaDepan,@namaTengah,@namaBelakang)
			END
	RETURN @HASIL
END
GO
SELECT dbo.Perkenalan('ALDY','NIFRATAMA',NULL);
GO
----MEMBUAT FUNCTION DENGAN TIPE DATA TABLE
--function tanpa parameter dan mengembalikan sebuah tabel
CREATE FUNCTION IbuKotaNegara() RETURNS @kotaKota TABLE(Kota varchar(50)) AS
BEGIN
	INSERT INTO @kotaKota VALUES('Jakarta'),('Washington fc'),('Moscow'),('Bangkok');
	RETURN
END
GO

CREATE OR ALTER FUNCTION NamaLengkap(@id int) RETURNS VARCHAR(150) AS
BEGIN
	DECLARE @firstname VARCHAR(150);
	DECLARE @lastname VARCHAR(150);
	--
	--
	--
	SELECT
		@firstname=FirstName,
		@lastname=LastName
	FROM Employees WHERE EmployeeID =@id
	RETURN CONCAT_WS(' ',@firstname,@lastname)
END
GO
--NILAI 2 DISINI DISEBUT SEBAGAI ARGUMEN
SELECT dbo.NamaLengkap(2) [Nama Kariyawan]
go

--------------------------------------------------------------------------------------------------------------------------------------
/*
	table value parameter harus menambahkan "READONLY"
*/
CREATE DATABASE COBA;
GO
USE COBA;
GO 
CREATE TYPE NilaiNilai AS table (
	Nilai int  not null
);
GO
CREATE FUNCTION PenjumlahanBanyakNilai(@banyakNilai AS NilaiNilai READONLY)
RETURNS int AS
BEGIN
	RETURN (SELECT SUM(Nilai) FROM @banyakNilai);
END
GO
DECLARE @VariableBanyakNilai  NilaiNilai;

INSERT INTO @VariableBanyakNilai VALUES 
(1),(2),(4),(10),(7);
PRINT dbo.PenjumlahanBanyakNilai(@VariableBanyakNilai);
GO
------------------------------------------------------------------------------------------
/*
WINDOW RANGKING FUNCTION
*/
USE Northwind
GO
--row number
SELECT pro.ProductID,pro.ProductName,pro.UnitPrice,pro.UnitsInStock,
	ROW_NUMBER() OVER (ORDER BY pro.UnitPrice,pro.UnitsInStock) [UnitPrice Rangking],
	ROW_NUMBER() OVER (ORDER BY pro.UnitsInStock) [UnitInStock Rangking]
FROM Products pro
ORDER BY [UnitPrice Rangking];
--RANK
SELECT pro.ProductID,pro.ProductName,pro.UnitPrice,pro.UnitsInStock,
	RANK() OVER (ORDER BY pro.UnitPrice) [UnitPrice Rangking],
	RANK() OVER (ORDER BY pro.UnitsInStock) [UnitInStock Rangking]
FROM Products pro
ORDER BY [UnitPrice Rangking];

--DENSE RANK
SELECT pro.ProductID,pro.ProductName,pro.UnitPrice,pro.UnitsInStock,
	DENSE_RANK() OVER (ORDER BY pro.UnitPrice) [UnitPrice Rangking],
	DENSE_RANK() OVER (ORDER BY pro.UnitsInStock) [UnitInStock Rangking]
FROM Products pro
ORDER BY [UnitPrice Rangking];


SELECT pro.ProductID,pro.ProductName,pro.UnitPrice,pro.UnitsInStock
	
FROM Products pro
ORDER BY UnitPrice,UnitsInStock


--window ranking function di tambahkan dengan partition (pengelompokan)
SELECT pro.ProductID,pro.ProductName,pro.UnitPrice,pro.UnitsInStock,pro.CategoryID,
	ROW_NUMBER() OVER (PARTITION BY pro.CategoryID ORDER BY pro.UnitPrice,pro.UnitsInStock) [UnitPrice Rangking],
	ROW_NUMBER() OVER (PARTITION BY pro.CategoryID ORDER BY pro.UnitsInStock) [UnitInStock Rangking]
FROM Products pro
ORDER BY CategoryID,[UnitPrice Rangking];

--window offeset function
--lag (LAG adalah fungsi yang memiliki kemampuan untuk membaca row sebelumnya.)
SELECT prod.ProductName, prod.CategoryID, prod.UnitPrice, 
LAG(prod.UnitPrice) OVER (ORDER BY prod.UnitPrice) AS [Lebih Murah],
prod.UnitsInStock,
LAG(prod.UnitsInStock) OVER (ORDER BY prod.UnitsInStock) AS [Lebih sedikit]
FROM dbo.Products AS prod
ORDER BY [Lebih Murah];

--LEAD (LEAD adalah fungsi yang memiliki kemampuan untuk membaca 1 row KE DEPAN.)
SELECT prod.ProductName, prod.CategoryID, prod.UnitPrice, 
LEAD(prod.UnitPrice) OVER (ORDER BY prod.UnitPrice) AS [Lebih Mahal],
prod.UnitsInStock,
LEAD(prod.UnitsInStock) OVER (ORDER BY prod.UnitsInStock) AS [Lebih Banyak]
FROM dbo.Products AS prod
ORDER BY UnitPrice DESC;

--lag + PARTITION
SELECT prod.ProductName, prod.CategoryID, prod.UnitPrice, prod.CategoryID,
LAG(prod.UnitPrice) OVER (PARTITION BY prod.CategoryID ORDER BY prod.UnitPrice) AS [Lebih Murah],
prod.UnitsInStock,
LAG(prod.UnitsInStock) OVER (PARTITION BY prod.CategoryID ORDER BY prod.UnitsInStock) AS [Lebih sedikit]
FROM dbo.Products AS prod
ORDER BY prod.CategoryID,UnitPrice;