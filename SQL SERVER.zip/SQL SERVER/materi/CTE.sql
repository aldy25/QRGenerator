use Northwind
/*
common table expression adalah nilai tabel (tabel value) YANG DIBERI NAMA DAN DISIMPAN SECARA SEMENTARA 
DAN ATURANYA HARUS ADA ALIAS NYA
*/

with contoh12 as 
(select 
AVG(p.UnitsInStock) [rata-rata unit per produk],
p.ProductName [nama produk]
from Products [p] group by p.ProductName )

select * from contoh12;


--

with contoh12 as (select p.ProductName,p.QuantityPerUnit  from Products [p])
select * from contoh12;


--contoh latihan yang menggunakan cte
--INI ADALAH JAWABAN LATIHAN SOAL 2 YANG MENGGUNAKAN CTE
with CustumersNotInEmployessCity AS (
	SELECT CUS.CustomerID, CUS.CompanyName, CUS.City FROM Customers [CUS]
	WHERE CUS.City NOT IN (SELECT DISTINCT City FROM Employees)
)
SELECT cus.CompanyName, SUP.CompanyName, SUP.[Address], COUNT (ORD.OrderID) [JUMLAH PESANAN]
FROM Orders [ORD]
		JOIN CustumersNotInEmployessCity [cus] on ORD.CustomerID = cus.CustomerID
		JOIN Suppliers [SUP] ON cus.City = SUP.City
GROUP BY cus.CompanyName, SUP.CompanyName, SUP.[Address];


