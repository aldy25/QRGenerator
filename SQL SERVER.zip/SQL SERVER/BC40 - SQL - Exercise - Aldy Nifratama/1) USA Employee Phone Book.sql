USE Northwind
--CARA 1
SELECT CONCAT(TitleOfCourtesy,' ' ,FirstName, ' ', LastName) [Nama Lengkap], HomePhone [Nomor Telepon]
FROM Employees 
where Country ='USA';

--CARA 2
SELECT CONCAT_WS(' ',TitleOfCourtesy,FirstName,LastName) [Nama Lengkap], HomePhone [Nomor Telepon]
FROM Employees 
where Country ='USA';
