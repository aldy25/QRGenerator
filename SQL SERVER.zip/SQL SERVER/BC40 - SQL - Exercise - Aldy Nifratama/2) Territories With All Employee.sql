USE Northwind

--CARA KE 1 FROM NYA DIMULAI DARI TABEL Territories
SELECT TER.TerritoryDescription AS [territory description], 
CONCAT_WS(' ',EM.TitleOfCourtesy, EM.FirstName, EM.LastName) [NAMA LENGKAP KARIYAWAN YANG BEKERJA]
FROM Territories [TER] 
LEFT JOIN EmployeeTerritories [EMPT] ON  TER.TerritoryID=EMPT.TerritoryID
LEFT JOIN Employees [EM] ON EMPT.EmployeeID = EM.EmployeeID

--CARA KE 1 FROM NYA DIMULAI DARI TABEL EmployeeTerritories
SELECT TER.TerritoryDescription AS [territory description], 
CONCAT_WS(' ',EM.TitleOfCourtesy, EM.FirstName, EM.LastName) [NAMA LENGKAP KARIYAWAN YANG BEKERJA]
FROM EmployeeTerritories [EMPT] 
RIGHT JOIN Territories [TER] ON EMPT.TerritoryID=TER.TerritoryID
LEFT JOIN Employees [EM] ON EMPT.EmployeeID = EM.EmployeeID