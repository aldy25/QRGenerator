USE Northwind
SELECT PRO.ProductName [Nama Product],SUP.CompanyName [Nama Perusahaan Supplier], 
CAT.CategoryName [Nama Category], PRO.QuantityPerUnit [Quantity], 
PRO.UnitsInStock [Unit In Stok]
FROM Products [PRO]
JOIN Categories [CAT] ON PRO.CategoryID = CAT.CategoryID
JOIN Suppliers [SUP] ON PRO.SupplierID=SUP.SupplierID
WHERE PRO.QuantityPerUnit LIKE '%glasses%' OR PRO.QuantityPerUnit LIKE '%bottles%' OR PRO.QuantityPerUnit LIKE '%jars%';