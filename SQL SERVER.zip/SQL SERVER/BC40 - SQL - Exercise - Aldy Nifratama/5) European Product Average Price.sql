use Northwind

SELECT  SUP.Country [Negara Suplier], AVG(UnitPrice) [Harga Rata-Rata Barang] 
FROM Products [PRO]
JOIN Suppliers [SUP] ON PRO.SupplierID = SUP.SupplierID
WHERE SUP.Country ='Germany' 
or SUP.Country ='Spain' or 
SUP.Country ='Sweden' or
SUP.Country ='Italy' or
SUP.Country ='Norway' or
SUP.Country ='Denmark' or
SUP.Country ='Netherland' or
SUP.Country ='Finland' or
SUP.Country ='France' 
GROUP BY SUP.Country
HAVING AVG(UnitPrice) <=50 
;