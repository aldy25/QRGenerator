

select TOP 1 S.CompanyName [NAMA PERUSAHAAN], COUNT(ShipVia) AS [JUMLAH ORDERAN]
FROM Orders [o]
JOIN Shippers [S] ON o.ShipVia = S.ShipperID
GROUP BY CompanyName
ORDER BY [JUMLAH ORDERAN] DESC;



