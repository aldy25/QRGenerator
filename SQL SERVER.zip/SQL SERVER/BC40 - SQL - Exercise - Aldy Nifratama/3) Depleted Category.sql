USE Northwind
SELECT TOP 2 CategoryID AS KATEGORI, SUM(UnitsInStock) AS [TOTAL STOK]
FROM Products
GROUP BY CategoryID
ORDER BY [TOTAL STOK] ASC;



