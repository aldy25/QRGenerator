CREATE FUNCTION CalculateAnnualBonus(@EmployeeID INT, @Tahun INT)
RETURNS MONEY
AS
BEGIN
    DECLARE @TotalPenjualan MONEY;
    DECLARE @Bonus MONEY;

    SELECT @TotalPenjualan = SUM(ordet.Quantity * ordet.UnitPrice)
    FROM Orders[ord]
    JOIN [Order Details] [ordet] ON ord.OrderID = ordet.OrderID
    WHERE ord.EmployeeID = @EmployeeID
      AND YEAR(ord.OrderDate) = @Tahun;
    -- Hitung bonus sebagai 10% dari total penjualan
    SET @Bonus = @TotalPenjualan * 0.1;
    RETURN @Bonus;
END;