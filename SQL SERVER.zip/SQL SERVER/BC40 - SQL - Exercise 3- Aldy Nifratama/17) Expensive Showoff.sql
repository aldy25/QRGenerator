WITH RankedProducts AS (
    SELECT
        S.CompanyName,
        SP.ProductName,
        SP.UnitPrice,
        DENSE_RANK() OVER (PARTITION BY S.SupplierID ORDER BY SP.UnitPrice DESC) AS ProductRankBySupplier
    FROM
        Suppliers S
    JOIN
        Products SP ON S.SupplierID = SP.SupplierID
),
MaxPricedProducts AS (
    SELECT
        CompanyName,
        ProductName,
        UnitPrice
    FROM
        RankedProducts
    WHERE
        ProductRankBySupplier = 1
)
SELECT
    CompanyName [Suplier Name],
    ProductName [Product Name],
    UnitPrice [UnitPrice Product],
    DENSE_RANK() OVER (ORDER BY UnitPrice DESC, ProductName ASC) AS [Supplier Rank]
FROM
    MaxPricedProducts
ORDER BY
    UnitPrice DESC,
    ProductName ASC;

