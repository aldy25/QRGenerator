CREATE OR ALTER FUNCTION CalculateProductQuantitybyPeriode(
    @ProductID INT,
    @Month INT,
    @Year INT
)
RETURNS INT
AS
BEGIN
    DECLARE @TotalSales INT;

    SELECT @TotalSales = SUM(ordet.Quantity)
    FROM Orders [ord]
    JOIN [Order Details] [ordet] ON ord.OrderID = ordet.OrderID
    WHERE ordet.ProductID = @ProductID
      AND MONTH(ord.OrderDate) = @Month
      AND YEAR(ord.OrderDate) = @Year;
    RETURN @TotalSales;
END;