CREATE OR ALTER FUNCTION CalculateTotalReorderCost()
RETURNS MONEY
AS
BEGIN
    DECLARE @TotalCost MONEY;

    SELECT @TotalCost = SUM(UnitPrice * ReorderLevel)
    FROM Products;

    RETURN @TotalCost;
END;

