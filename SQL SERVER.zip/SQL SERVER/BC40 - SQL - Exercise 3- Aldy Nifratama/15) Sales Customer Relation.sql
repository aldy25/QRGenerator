
CREATE OR ALTER VIEW SalesmenCustumerHistoryOrder AS
SELECT
    CONCAT(emp.FirstName, ' ', emp.LastName) AS SalesmanName,
    cus.ContactName AS CustomerName
FROM
    Orders [ord]
INNER JOIN
    Employees [emp] ON ord.EmployeeID = emp.EmployeeID
INNER JOIN
    Customers [cus] ON ord.CustomerID = cus.CustomerID;

