CREATE OR ALTER FUNCTION CalculateTotalMeatOrders(@Tahun INT)
RETURNS INT
AS
BEGIN
    DECLARE @TotalOrders INT;

    SELECT @TotalOrders = COUNT(ord.OrderID)
    FROM Orders [ord]
    JOIN [Order Details] [ordet] ON ord.OrderID = ordet.OrderID
    JOIN Products [pro] ON ordet.ProductID = pro.ProductID
    WHERE pro.CategoryID = 6
      AND YEAR(ord.OrderDate) = @Tahun;

    RETURN @TotalOrders;
END;
