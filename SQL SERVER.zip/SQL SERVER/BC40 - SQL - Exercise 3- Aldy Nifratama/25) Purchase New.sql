CREATE TYPE Cart AS TABLE
(
Quantity INT NOT NULL,
ProductID INT NOT NULL
);

GO
CREATE PROCEDURE dbo.UpdateSalesPurchaseData
(
    @CustomerName NVARCHAR(255),
    @EmployeeName NVARCHAR(255),
    @ShipperName NVARCHAR(255),
    @Cart Cart READONLY
)
AS
BEGIN
    -- Mulai transaksi
    BEGIN TRY
        BEGIN TRANSACTION;

        -- Update data order
        DECLARE @OrderID INT;
        INSERT INTO Orders (CustomerID, EmployeeID, OrderDate, ShipVia)
        VALUES (@CustomerName, @EmployeeName, GETDATE(), @ShipperName);
        SET @OrderID = SCOPE_IDENTITY();

        -- Update detail pembelian
        INSERT INTO [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount)
        SELECT @OrderID, Cart.ProductID, pro.UnitPrice, Cart.Quantity, 0
        FROM @Cart [Cart]
        INNER JOIN Products [pro] ON Cart.ProductID = pro.ProductID;

        -- Kurangi jumlah unit in stock pada table product
        UPDATE Products
        SET UnitsInStock = UnitsInStock - Cart.Quantity
        FROM @Cart [Cart]
        WHERE Products.ProductID = Cart.ProductID;

        -- Commit transaksi jika semuanya berhasil
        COMMIT;
    END TRY
    BEGIN CATCH
        -- Rollback transaksi jika terjadi kesalahan
        ROLLBACK;
        -- Masukkan pesan kesalahan ke dalam log atau lakukan tindakan lain sesuai kebutuhan
        -- RAISEERROR...
    END CATCH;
END;
