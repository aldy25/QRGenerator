CREATE OR ALTER PROCEDURE PIVOTQuantityProductbyShipper
	(
		@tahun DATE
	)
AS
BEGIN
	SELECT * 
	FROM (SELECT 
		CASE
			WHEN pro.CategoryID =1 THEN 'Category 1'
			WHEN pro.CategoryID =2 THEN 'Category 2'
			WHEN pro.CategoryID =3 THEN 'Category 3'
			WHEN pro.CategoryID =4 THEN 'Category 4'
			WHEN pro.CategoryID =5 THEN 'Category 5'
			WHEN pro.CategoryID =6 THEN 'Category 6'
			WHEN pro.CategoryID =7 THEN 'Category 7'
			WHEN pro.CategoryID =8 THEN 'Category 8'
		END [category],
			ordet.Quantity [quantity], 
			ship.CompanyName [shiper] 
		FROM Orders [ord] 
		join [Order Details] [ordet] on ord.OrderID = ordet.OrderID
		join Products [pro] on pro.ProductID = ordet.ProductID
		join Shippers [ship] on ord.ShipVia = ship.ShipperID
		WHERE ord.OrderDate = @tahun ) [procat]
		PIVOT(
			SUM(procat.quantity)
				FOR procat.shiper IN([Federal Shipping],[Speedy Express],[United Package])
		) AS ppvt
END




