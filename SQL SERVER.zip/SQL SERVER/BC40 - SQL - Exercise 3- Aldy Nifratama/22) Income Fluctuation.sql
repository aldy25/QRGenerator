SELECT 
	CONVERT (date, ord.OrderDate)[Tanggal] , 
	CONVERT(money,SUM((ordet.UnitPrice * ordet.Quantity)-(ordet.Discount * (ordet.UnitPrice * ordet.Quantity)))) [Pendapatan Perhari],
	(CONVERT(money,SUM((ordet.UnitPrice * ordet.Quantity)-(ordet.Discount * (ordet.UnitPrice * ordet.Quantity)))) - 
	LAG(CONVERT(money,SUM((ordet.UnitPrice * ordet.Quantity)-(ordet.Discount * (ordet.UnitPrice * ordet.Quantity))))) 
	OVER (ORDER BY CONVERT (date, ord.OrderDate))) [Selisi Pendapatan Perhari]
FROM Orders [ord]
	JOIN [Order Details] [ordet] on ord.OrderID = ordet.OrderID
GROUP BY ord.OrderDate
ORDER BY CONVERT (date, ord.OrderDate)

