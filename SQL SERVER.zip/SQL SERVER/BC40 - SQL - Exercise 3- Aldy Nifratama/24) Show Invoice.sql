
CREATE OR ALTER PROCEDURE UpdateSalesOrder
	@orderID INT
AS
BEGIN 
	SELECT  FORMAT(ORD.OrderDate,'dd MMM yyyy','en-US') [Order Date],
			CUS.CompanyName [Customer],
			CONCAT(EMP.FirstName,' ', EMP.LastName) AS [Salesmen],
			SHIP.CompanyName [Shipper],
			FORMAT(ord.ShippedDate,'dd MMM yyyy','en-US') [Ship Date],
			CONVERT(money,((SUM(
					(ORDET.Quantity * ORDET.UnitPrice)-(ORDET.Quantity* ORDET.UnitPrice*ORDET.Discount)
				 )
			   )+ ORD.Freight)) [Total Cost]
		FROM Orders [ORD]
		JOIN Customers [CUS] ON CUS.CustomerID = ORD.CustomerID
		JOIN Employees [EMP] ON ORD.EmployeeID = EMP.EmployeeID
		JOIN Shippers [SHIP] ON SHIP.ShipperID = ORD.ShipVia
		JOIN [Order Details] [ORDET] ON ORD.OrderID = ORDET.OrderID
		WHERE ORD.OrderID =@orderID
		GROUP BY ORD.OrderDate,CUS.CompanyName,SHIP.CompanyName,ORD.ShippedDate,CONCAT(EMP.FirstName,' ', EMP.LastName),ORD.Freight


	SELECT 
		PRO.ProductName [Product],
		SUP.CompanyName [Suplier],
		ORD.Quantity [Quantity],
		FORMAT( ORD.UnitPrice ,'C','en-US')[Price Per Unit],
		FORMAT( ((ORD.Quantity * ORD.UnitPrice) - ((ORD.Quantity*ORD.UnitPrice)*(Discount))),'C','en-US') [Total]
		
		FROM [Order Details] [ORD]
		JOIN Products [PRO] ON ORD.ProductID = PRO.ProductID
		JOIN Suppliers [SUP] ON SUP.SupplierID = PRO.SupplierID
	WHERE ORD.OrderID =@orderID
END
EXEC UpdateSalesOrder 10263
