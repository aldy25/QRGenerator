SELECT  pro.UnitsInStock [Stock],
	CASE 
		WHEN pro.UnitsInStock <= 20 THEN CONCAT(pro.ProductName,' ', 'insufficient')
		WHEN pro.UnitsInStock < 80 THEN CONCAT(pro.ProductName,' ', 'sufficient')
		WHEN pro.UnitsInStock >= 80 THEN CONCAT(pro.ProductName,' ', 'abundant')
	END [Product Name]
FROM Products [pro]