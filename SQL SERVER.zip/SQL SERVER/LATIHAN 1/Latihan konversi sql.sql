-------------------------------------------------------------------------------------------------------
--INI UNTUK QUERY TANPA WITH/CTE
SELECT

od.OrderID,
C.CompanyName [Customer Name],
FORMAT(o.OrderDate,'MMM dd yyyy','en-US') [Tanggal Pesan],
FORMAT(o.RequiredDate,'MMM dd yyyy','en-US')  [Tanggal Dibutuhkan],
FORMAT(o.ShippedDate,'MMM dd yyyy','en-US') [Tanggal Dikirim],
DATEDIFF(day,o.RequiredDate,o.ShippedDate) [Hari Terlambat],
FORMAT(ROUND(SUM((od.Quantity * od.UnitPrice)-(od.Quantity*od.UnitPrice*od.Discount)),0),'C','en-US') [Total Biaya],
FORMAT(sum((DATEDIFF(day,o.RequiredDate,o.ShippedDate))*0.01 *  ( ROUND(((od.Quantity * od.UnitPrice)-(od.Quantity*od.UnitPrice*od.Discount)),0)) ),'C','en-US')   [Harga Terlambat],
FORMAT(sum(( ROUND(((od.Quantity * od.UnitPrice)-(od.Quantity*od.UnitPrice*od.Discount)),0))-((DATEDIFF(day,o.RequiredDate,o.ShippedDate))*0.01 * ( ROUND(((od.Quantity * od.UnitPrice)-(od.Quantity*od.UnitPrice*od.Discount)),0)))),'C','en-US')  [Harga Sesudah]

FROM Orders [o] 
join [Order Details][od]  on od.OrderID =o.OrderID 
JOIN  Customers [C] ON O.CustomerID=C.CustomerID
WHERE DATEDIFF(day,o.RequiredDate,o.ShippedDate) >0
group by od.OrderID,C.CompanyName,o.OrderDate,o.RequiredDate,o.ShippedDate
order  by od.OrderID
;


-----------------------------------------------------------------------------------------------------------
----INI UNTUL QUERY YANG CTE
DECLARE @formatTanggal AS VARCHAR(25) = 'MMM dd, yyyy';
--harus tau harga normalnya berapa sebelum diberi 1% diskon setiap keterlambatan 1 hari
with OrderDetailSum as (
SELECT OrderID,ROUND(SUM(UnitPrice * Quantity -(UnitPrice * Quantity *Discount)),0) [Total]
FROM [Order Details] [orDet]
group by OrderID
)

select ord.OrderID,
	cus.CompanyName,
	FORMAT(ord.OrderDate,@formatTanggal) [Tanggal Pesan],
	FORMAT(ord.RequiredDate,@formatTanggal) [Tanggal Dibuthkan],
	FORMAT(ord.ShippedDate,@formatTanggal) [Tanggal Dikirim],
	DATEDIFF(day,ord.RequiredDate,ord.ShippedDate) [Hari Terlambat],
	FORMAT(orDetSum.Total,'C','en-US') [Total Biaya],
	FORMAT(DATEDIFF(DAY,ord.RequiredDate,ord.ShippedDate) * orDetSum.Total /100,'C','en-US') [HARGA Keterlambatan],
	FORMAT(orDetSum.Total -(DATEDIFF(DAY,ord.RequiredDate,ord.ShippedDate) * orDetSum.Total /100),'C','en-US') [Harga Baru]
from
	OrderDetailSum [orDetSum]
	join Orders [ord] on ord.OrderID = orDetSum.OrderID
	join Customers cus on cus.CustomerID =ord.CustomerID
where DATEDIFF(day,ord.RequiredDate, ord.ShippedDate)>0
