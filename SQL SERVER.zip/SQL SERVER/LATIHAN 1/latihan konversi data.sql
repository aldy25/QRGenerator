
SELECT ProductName,
		SUBSTRING(QuantityPerUnit,PATINDEX('%-%',QuantityPerUnit)+1,PATINDEX('%g%',QuantityPerUnit)-
		PATINDEX('%-%',QuantityPerUnit))
		[Berat Maksimal Gram] 
FROM Products
WHERE QuantityPerUnit LIKE '%g pkgs%';

