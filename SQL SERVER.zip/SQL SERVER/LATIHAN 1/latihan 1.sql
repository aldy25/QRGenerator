select
c.CompanyName [Customers] ,s.CompanyName [Suplliers],s.[Address] [Alamat Suplliers],
count(distinct o.OrderID) [Jumlah Pesanan]
 from Orders [o]											--830
  join [Order Details] [od] on o.OrderID = [od].OrderID		--830 dicocokan dengan 77
	join Customers [c] on o.CustomerID = c.CustomerID		--830 dicocokan dengan 29, hasilnya 100
	join Suppliers [s] on c.City=s.City
 group by c.CompanyName, s.CompanyName, s.[Address]			--13
;


select
c.CompanyName [Customers] ,s.CompanyName [Suplliers],s.[Address] [Alamat Suplliers],
count(distinct o.OrderID) [Jumlah Pesanan]
 from Orders [o]											--830
  join [Order Details] [od] on o.OrderID = [od].OrderID		--830 dicocokan dengan 77
	join Customers [c] on o.CustomerID = c.CustomerID		--830 dicocokan dengan 29, hasilnya 100
	join Suppliers [s] on c.City=s.City
 group by c.CompanyName, s.CompanyName, s.[Address]			--13
;



--di bawah ini kodenya menggunakan where
select
c.CompanyName [Customers] ,s.CompanyName [Suplliers],s.[Address] [Alamat Suplliers],
count(distinct o.OrderID) [Jumlah Pesanan]
 from Orders [o]
	join Customers [c] on o.CustomerID = c.CustomerID
	join Suppliers [s] on c.City=s.City
	 where  c.City IN (
	SELECT DISTINCT s.City
	FROM Suppliers 
 )
    group by c.CompanyName, s.CompanyName, s.[Address]
;





