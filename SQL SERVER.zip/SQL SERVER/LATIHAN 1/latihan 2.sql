select
c.CompanyName [Customers] ,s.CompanyName [Suplliers],s.[Address] [Alamat Suplliers],
count(distinct o.OrderID) [Jumlah Pesanan]
 from Orders [o]
  join [Order Details] [od] on o.OrderID = [od].OrderID
	join Customers [c] on o.CustomerID = c.CustomerID
	join Suppliers [s] on c.City=s.City
	where c.City  not IN (
	SELECT DISTINCT e.City
	FROM Employees [e] 
)
 group by c.CompanyName, s.CompanyName, s.[Address]
;



select
c.CompanyName [Customers] ,s.CompanyName [Suplliers],s.[Address] [Alamat Suplliers],
count(distinct o.OrderID) [Jumlah Pesanan]
 from Orders [o]
  join [Order Details] [od] on o.OrderID = [od].OrderID
	join Customers [c] on o.CustomerID = c.CustomerID
	join Suppliers [s] on c.City=s.City
 where  c.City IN (
	SELECT DISTINCT s.City
	FROM Suppliers 
)and  c.City  not IN (
	SELECT DISTINCT e.City
	FROM Employees [e] 
)
 group by c.CompanyName, s.CompanyName, s.[Address]
;