DECLARE @WarnaLampu AS VARCHAR(10)='Merah'
DECLARE @Pengemudi AS VARCHAR(50)='Keras Kepala'
DECLARE @Polisi AS VARCHAR(50)='Ada'

--ini hasil sebelum di tambah digabung
IF (@WarnaLampu ='Hijau')
	PRINT 'Jalan';
ELSE IF   (@WarnaLampu ='Kuning')
	PRINT 'Hati-Hati'
ELSE IF	(@WarnaLampu ='Merah')
	PRINT 'Berhenti';
ELSE
	PRINT 'Bukan Warna Lampu Lalu Lintas';


--ini yang menjadi tambahan
IF (@WarnaLampu ='Hijau')
	PRINT 'Jalan';
ELSE IF (@WarnaLampu ='Kuning' AND @Pengemudi='Keras Kepala')
	PRINT 'Ngebut';
ELSE IF   (@WarnaLampu ='Kuning')
	PRINT 'Hati-Hati'
ELSE IF	(@WarnaLampu ='Merah' AND @Polisi='Ada' AND @Pengemudi='Keras Kepala')
	PRINT 'Jalan' +' ' + 'Ditilang';
ELSE IF	(@WarnaLampu ='Merah' AND @Polisi='Tidak Ada' AND @Pengemudi='Keras Kepala')
	PRINT 'Jalan' + ' '+'Nabrak';
ELSE IF	(@WarnaLampu ='Merah')
	PRINT 'Berhenti';
ELSE
	PRINT 'Bukan Warna Lampu Lalu Lintas';