CREATE DATABASE MarketPlace;
GO

USE MarketPlace;

GO
CREATE TABLE Akun (
	AkunID VARCHAR (5) PRIMARY KEY,
	Username Varchar (20) UNIQUE NOT NULL ,
	[Password] Varchar (70) NOT NULL ,
	LevelAkun Varchar (7) NOT NULL CHECK(LevelAkun='Admin' OR LevelAkun='Pembeli' OR LevelAkun='Penjual'),
	StatusAkun BIT DEFAULT(1),
	TanggalDaftar DATETIME NOT NULL DEFAULT(GETDATE()),
);
GO
CREATE TABLE Penjual (
	PenjualID VARCHAR(5) PRIMARY KEY,
	NamaDepan VARCHAR(50) NOT NULL,
	NamaBelakang VARCHAR(50),
	JenisKelamin VARCHAR(1) NOT NULL CHECK(JenisKelamin='L' OR JenisKelamin='P'),
	TanggalLahir DATE NOT NULL,
	TempatLahir Varchar(50) NOT NULL,
	KontakHP VARCHAR(15) NOT NULL,
	TabunganPenjual MONEY NOT NULL DEFAULT(0),
	Alamat VARCHAR(500) NOT NULL,
	AkunID VARCHAR(5) NOT NULL UNIQUE FOREIGN KEY REFERENCES Akun(AkunID) 
);
GO
CREATE TABLE [Admin] (
	AdminID VARCHAR(5) PRIMARY KEY,
	NamaDepan VARCHAR(50) NOT NULL,
	NamaBelakang VARCHAR(50),
	JenisKelamin VARCHAR(1) NOT NULL CHECK(JenisKelamin='L' OR JenisKelamin='P'),
	TanggalLahir DATE NOT NULL,
	KontakHP VARCHAR(15) NOT NULL,
	AkunID VARCHAR(5) NOT NULL UNIQUE FOREIGN KEY REFERENCES Akun(AkunID) 
);
GO
CREATE TABLE Pembeli (
	PembeliID VARCHAR(5) PRIMARY KEY,
	NamaDepan VARCHAR(50) NOT NULL,
	NamaBelakang VARCHAR(50),
	JenisKelamin VARCHAR(1) NOT NULL CHECK(JenisKelamin='L' OR JenisKelamin='P'),
	TanggalLahir DATE NOT NULL,
	TempatLahir Varchar(50) NOT NULL,
	KontakHP VARCHAR(15) NOT NULL,
	TabunganPembeli MONEY NOT NULL DEFAULT(0),
	Alamat VARCHAR(500) NOT NULL,
	AkunID VARCHAR(5)NOT NULL UNIQUE FOREIGN KEY REFERENCES Akun(AkunID) 
);
GO
CREATE TABLE JasaPengiriman (
	JasaPengirimanID VARCHAR(5) PRIMARY KEY,
	NamaJasaPengiriman VARCHAR(50) NOT NULL,
	KontakHP VARCHAR(15) NOT NULL
);
GO
CREATE TABLE KategoriProduk(
	KategoriProdukID VARCHAR(5) PRIMARY KEY,
	NamaKategori VARCHAR(50) NOT NULL,
	Deskripsi VARCHAR(1000) NOT NULL
);
GO
CREATE TABLE KotaPengiriman (
	KotaPengirimID VARCHAR(5) PRIMARY KEY,
	NamaKota VARCHAR(50) NOT NULL
);
GO
CREATE TABLE KotaPenerima (
	KotaPenerimaID VARCHAR(5) PRIMARY KEY,
	NamaKota VARCHAR(50) NOT NULL
);
GO
CREATE TABLE RutePengiriman (
	RutePengirimanID VARCHAR(5) PRIMARY KEY,
	KotaPengirimanID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES KotaPengiriman(KotaPengirimID),
	KotaPenerimaID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES KotaPenerima(KotaPenerimaID)
);
GO
CREATE TABLE TarifPengiriman (
	TarifPengirimanID VARCHAR(5) PRIMARY KEY,
	HargaTarif MONEY NOT NULL DEFAULT(0),
	RutePengirimanID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES RutePengiriman(RutePengirimanID),
	JasaPengirimanID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES JasaPengiriman(JasaPengirimanID)
);
GO
CREATE TABLE AlamatPenerima (
	AlamatPenerimaID VARCHAR(5) PRIMARY KEY,
	NamaPenerima VARCHAR(50) NOT NULL,
	KontakHP VARCHAR(15) NOT NULL,
	DetailAlamat VARCHAR(500) NOT NULL ,
	KodePos INT,
	KotaPenerimaID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES KotaPenerima(KotaPenerimaID),
	PembeliID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES Pembeli(PembeliID)
);
GO 
CREATE TABLE IsiUlangTabungan(
	IsiUlangTabunganID VARCHAR(5) PRIMARY KEY,
	Jumlah MONEY NOT NULL,
	Tanggalisi DATETIME NOT NULL DEFAULT(GETDATE()),
	PembeliID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES Pembeli(PembeliID)
);
GO
CREATE TABLE Toko(
	TokoID VARCHAR(5) PRIMARY KEY,
	NamaToko VARCHAR(50),
	TanggalDibuat DATETIME NOT NULL DEFAULT(GETDATE()),
	Alamat VARCHAR(500) NOT NULL,
	KotaPengirimID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES KotaPengiriman(KotaPengirimID),
	PenjualID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES Penjual(PenjualID)
);
GO
CREATE TABLE Produk (
	ProdukID VARCHAR(5) PRIMARY KEY,
	NamaProduk VARCHAR(50) NOT NULL,
	Harga MONEY NOT NULL DEFAULT(0),
	Deskripsi VARCHAR(MAX) NOT NULL,
	JumlahPersediaan INT,
	JumlahMinimalPembelian TINYINT NOT NULL DEFAULT(1),
	TanggalMulaiDijual DATETIME NOT NULL DEFAULT(GETDATE()),
	TokoID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES Toko(TokoID),
	KategoriProdukID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES KategoriProduk(KategoriProdukID) 
);
GO
CREATE TABLE Ulasan (
	UlasanID VARCHAR(5) PRIMARY KEY,
	Bintang TINYINT NOT NULL CHECK(Bintang  BETWEEN 1 AND 5) DEFAULT(0),
	Komentar VARCHAR(MAX),
	ProdukID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES Produk(ProdukID),
	PembeliID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES Pembeli(PembeliID)
);
GO
CREATE TABLE Diskusi (
	UlasanID VARCHAR(5) PRIMARY KEY,
	PertanyaanPembeli VARCHAR(MAX) NOT NULL,
	JawabanPenjual VARCHAR(MAX),
	ProdukID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES Produk(ProdukID),
	PembeliID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES Pembeli(PembeliID)
);
GO 
CREATE TABLE Transaksi (
	TransaksiID VARCHAR(5) PRIMARY KEY,
	TanggalMulaiTransaksi DATETIME NOT NULL DEFAULT(GETDATE()),
	TanggalDibatalkan DATETIME,
	TanggalSelesaiTransaksi DATETIME,
	StatusTransaksi VARCHAR(50) CHECK(StatusTransaksi='DalamKeranjang' OR StatusTransaksi='Dikemas' OR StatusTransaksi='Dikirim'
	OR StatusTransaksi='Dibatalkan' OR StatusTransaksi='Diterima' OR StatusTransaksi='Selesai'),
	TarifPengiriman MONEY NOT NULL DEFAULT(0),
	DetailAlamat VARCHAR(500) NOT NULL,
	TarifPengirimanID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES TarifPengiriman(TarifPengirimanID),
	PembeliID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES Pembeli(PembeliID),
	AlamatPenerimaID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES AlamatPenerima(AlamatPenerimaID)
);
GO

CREATE TABLE DetailTransaksi (
	TransaksiID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES Transaksi(TransaksiID), 
	ProdukID VARCHAR(5) NOT NULL FOREIGN KEY REFERENCES Produk(ProdukID),
	Harga MONEY NOT NULL DEFAULT(0),
	JumlahPembelian SMALLINT NOT NULL DEFAULT(0),
	PRIMARY KEY (TransaksiID,ProdukID)
);


