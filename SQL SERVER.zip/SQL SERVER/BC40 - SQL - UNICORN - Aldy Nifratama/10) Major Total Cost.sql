USE Unicorn
GO
WITH TotalCosts AS (
    SELECT
		m.[Name] [Major Name],
		CASE 
			WHEN m.[Type] ='FM' THEN 'Full-Major'
			WHEN m.[Type] ='SM' THEN 'Sub-Major'
			WHEN m.[Type] ='EL' THEN 'Elective'
		END [Major Type],
        SUM(s.Cost) AS "Total Cost"
    FROM
        Major  [m]
    INNER JOIN
        [Subject] [s] ON s.MajorID = m.ID
    GROUP BY
        m.[Name], m.[Type]
)
SELECT
    DENSE_RANK() OVER (ORDER BY "Total Cost" ASC) AS "Rank",
    "Major Name",
    "Major Type",
    "Total Cost"
FROM
    TotalCosts
ORDER BY
    "Total Cost" ASC;




