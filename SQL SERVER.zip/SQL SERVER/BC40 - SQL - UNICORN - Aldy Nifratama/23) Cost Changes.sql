USE Unicorn
GO
USE Unicorn
GO
SELECT
    S.Code AS "Subject Code",
    S.Name AS "Subject Name",
    S.Cost AS "Current Price",
    E.TransactionDate AS "Transaction Date",
    E.Fee AS "Price on Transaction",
    (S.Cost - E.Fee) AS "Selisih Harga"
FROM
    StudentMajor SM
	JOIN Subject [S] ON SM.MajorID = S.MajorID
	JOIN Enrollment E ON SM.StudentNumber = E.StudentNumber
WHERE 
	E.TransactionDate IS NOT NULL
	ORDER BY
    E.TransactionDate ASC ;

