USE Unicorn
GO
SELECT
    edu.Institution [Institusi Pendidikan],
    AVG(edu.Grade) [Rata-Rata Nilai]
FROM
    EducationHistory [edu]
GROUP BY
    edu.Institution
