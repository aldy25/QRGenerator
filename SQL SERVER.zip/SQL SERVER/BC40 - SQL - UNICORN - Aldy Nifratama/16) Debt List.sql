USE Unicorn
GO
SELECT
    e.StudentNumber [Student Number],
	CONCAT_WS(' ',stu.FirstName,stu.MiddleName,stu.LastName) [Student Full Name],
    SUM(s.Cost) [Total Debt]
FROM Enrollment [e]
	JOIN Student [stu] ON e.StudentNumber=stu.StudentNumber
	JOIN [Period] [p] ON p.ID = e.PeriodID
	JOIN Competency [c] ON c.ID = p.CompetencyID
	JOIN [Subject] [s] ON S.ID = C.SubjectID
WHERE
    e.[Status] = 'PEN'
GROUP BY
    e.StudentNumber,CONCAT_WS(' ',stu.FirstName,stu.MiddleName,stu.LastName)
ORDER BY
    [Total Debt] DESC;
