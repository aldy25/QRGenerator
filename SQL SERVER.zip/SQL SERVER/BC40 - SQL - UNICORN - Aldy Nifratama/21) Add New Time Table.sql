USE Unicorn
GO
CREATE OR ALTER PROCEDURE AddOrUpdateClassSchedule
    @PeriodID INT,
    @NamaHari NVARCHAR(255),
    @StartTime TIME,
    @EndTime TIME
AS
BEGIN
   BEGIN TRANSACTION
		BEGIN TRY
			IF NOT EXISTS(SELECT * FROM Period WHERE ID=@periodID)
				PRINT 'Maaf Period Tidak Ditemukan'
			ELSE
				IF (@NamaHari = 'Monday')
					IF EXISTS(SELECT MondayFrom, MondayTo FROM TimeTable WHERE PeriodID=@periodID)
						BEGIN
							UPDATE TimeTable SET MondayFrom=@startTime, MondayTo=@endTime
							WHERE PeriodID=@periodID
						END
					ELSE
						BEGIN
							INSERT INTO TimeTable(PeriodID,MondayFrom,MondayTo)
							VALUES (@periodID,@startTime,@endTime)
						END
				ELSE IF (@NamaHari = 'Tuesday')
					IF EXISTS(SELECT TuesdayFrom, TuesdayTo FROM TimeTable WHERE PeriodID=@periodID)
						BEGIN
							UPDATE TimeTable SET TuesdayFrom=@startTime, TuesdayTo=@endTime
							WHERE PeriodID=@periodID
						END
					ELSE
						BEGIN
							INSERT INTO TimeTable(PeriodID,TuesdayFrom,TuesdayTo)
							VALUES (@periodID,@startTime,@endTime)
						END
				ELSE IF (@NamaHari = 'Wednesday')
					IF EXISTS(SELECT WednesdayFrom, WednesdayTo FROM TimeTable WHERE PeriodID=@periodID)
						BEGIN
							UPDATE TimeTable SET WednesdayFrom=@startTime, WednesdayTo=@endTime
							WHERE PeriodID=@periodID
						END
					ELSE
						BEGIN
							INSERT INTO TimeTable(PeriodID,WednesdayFrom,WednesdayTo)
							VALUES (@periodID,@startTime,@endTime)
						END
				ELSE IF (@NamaHari = 'Thursday')
					IF EXISTS(SELECT ThursdayFrom, ThursdayTo FROM TimeTable WHERE PeriodID=@periodID)
						BEGIN
							UPDATE TimeTable SET ThursdayFrom=@startTime, ThursdayTo=@endTime
							WHERE PeriodID=@periodID
						END
					ELSE
						BEGIN
							INSERT INTO TimeTable(PeriodID,ThursdayFrom,ThursdayTo)
							VALUES (@periodID,@startTime,@endTime)
						END
				ELSE IF (@NamaHari = 'Friday')
					IF EXISTS(SELECT FridayFrom, FridayTo FROM TimeTable WHERE PeriodID=@periodID)
						BEGIN
							UPDATE TimeTable SET FridayFrom=@startTime, FridayTo=@endTime
							WHERE PeriodID=@periodID
						END
					ELSE
						BEGIN
							INSERT INTO TimeTable(PeriodID,FridayFrom,FridayTo)
							VALUES (@periodID,@startTime,@endTime)
						END
				ELSE
					PRINT('Nama Hari Yang Diinputkan Salah')
			COMMIT
		END TRY
		BEGIN CATCH
			ROLLBACK
		END CATCH
END;
GO
EXEC AddOrUpdateClassSchedule 10444,'Friday','12:00', '14:00'