USE Unicorn
GO
SELECT
    t.StaffNumber AS [Staff Number],
    CONCAT(t.FirstName, ' ', t.MiddleName, ' ', t.LastName) AS "Employee Full Name",
    CASE
        WHEN t.EmployeeType = 'FC' THEN 'Full-time Contract'
        WHEN t.EmployeeType = 'FP' THEN 'Full-time Permanent'
        WHEN t.EmployeeType = 'PC' THEN 'Part-time Contract'
        WHEN t.EmployeeType = 'CA' THEN 'Casual'
    END AS [Employee Type],
    CASE
        WHEN t.EmployeeType = 'FC' THEN CONVERT(money,t.BasicSalary)
        WHEN t.EmployeeType = 'FP' THEN convert(money,( t.BasicSalary + (t.BasicSalary * 0.15)))
        WHEN t.EmployeeType = 'PC' THEN CONVERT(money, t.BasicSalary * 2)
        WHEN t.EmployeeType = 'CA' THEN CONVERT(money, t.BasicSalary * 2)
    END AS "Take Homepay"
FROM
    Tutor AS t;

SELECT * FROM Tutor

