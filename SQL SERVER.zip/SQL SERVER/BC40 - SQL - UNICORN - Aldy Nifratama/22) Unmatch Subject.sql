USE Unicorn
GO
SELECT
    mj.Name AS [Major Name],
    CASE
        WHEN mj.Level = 'B' THEN 'Bachelor'
        WHEN mj.Level = 'M' THEN 'Master'
        WHEN mj.Level = 'P' THEN 'PhD'
    END AS "Major Level",
    s.[Name] AS "Subject Name",
    CASE
        WHEN s.Level = 'B' THEN 'Bachelor'
        WHEN s.Level = 'M' THEN 'Master'
        WHEN s.Level = 'P' THEN 'PhD'
    END AS "Subject Level"
FROM
    Major [mj]
	JOIN
    [Subject] s ON mj.ID = s.MajorID
WHERE
    (
        (mj.Level = 'B' AND s.Level != 'B' AND s.Level !='M' AND s.Level !='P') OR
        (mj.Level = 'M' AND s.Level != 'M') OR
        (mj.Level = 'P' AND s.Level !='P')
    )
    AND s.NonActiveDate IS NULL ;
