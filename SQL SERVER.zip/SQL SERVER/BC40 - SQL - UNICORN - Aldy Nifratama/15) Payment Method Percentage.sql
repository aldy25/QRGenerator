USE Unicorn
GO
SELECT
	CASE 
		WHEN PaymentMethod = 'BT' THEN 'Bank Transfer'
		WHEN PaymentMethod = 'AC' THEN 'Auto Collection'
		WHEN PaymentMethod = 'CH' THEN 'Credit Card'
		WHEN PaymentMethod = 'CC' THEN 'Cheque'
	END [Payment Method],

	CONCAT( ROUND((CONVERT(float,(COUNT(*))) /
	CONVERT(float,(SELECT COUNT(*) FROM Enrollment WHERE  PaymentMethod IS NOT NULL)))* 100,0 ),' %')  [Percentage]
FROM
    Enrollment
	WHERE  PaymentMethod IS NOT NULL
GROUP BY
     PaymentMethod
ORDER BY
   [Percentage] DESC;
