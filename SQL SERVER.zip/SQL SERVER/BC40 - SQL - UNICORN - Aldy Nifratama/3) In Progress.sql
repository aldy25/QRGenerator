USE Unicorn
GO
SELECT CONCAT_WS(' ',s.FirstName, s.MiddleName, s.LastName) [Nama Lengkap],
	   CONCAT(c.[Name],', ',FORMAT(s.BirthDate, 'dd MMMM yyyy','id')) [Kelahiran],
	   M.[Name] [Major Name]
FROM Student [s]
	LEFT JOIN [Certificate] [cer] on s.StudentNumber = cer.StudentNumber
	JOIN StudentMajor [sm] ON s.StudentNumber = sm.StudentNumber
	JOIN Major [m] ON M.ID = SM.MajorID
	JOIN City [c] on c.ID = s.BirthCityID
	WHERE cer.ID IS NULL

