USE Unicorn
GO
CREATE OR ALTER PROCEDURE GetMajorSubjects
    @MajorNameKeyword VARCHAR(50)
AS
BEGIN
    SELECT
        s.[Name] [Nama],
        ISNULL(s.Description, 'Ask student call center for this subject information')  [Deskripsi],
        CASE
            WHEN s.[Level] = 'B' THEN 'Bachelor'
			WHEN s.[Level] = 'M' THEN 'Master'
            WHEN s.[Level] = 'P' THEN 'Phd'
        END  [Level],
        s.Cost [Cost]
    FROM
        Subject AS s
    INNER JOIN
        Major AS m ON s.MajorID = m.ID
    WHERE
        m.[Name] LIKE '%' + @MajorNameKeyword + '%';
END
