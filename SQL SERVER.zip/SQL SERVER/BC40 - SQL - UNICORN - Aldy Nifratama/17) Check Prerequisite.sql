USE Unicorn
GO
CREATE OR ALTER FUNCTION CanStudentTakeSubject
(
    @StudentNumber NVARCHAR(255),
    @SubjectCode NVARCHAR(255)
)
RETURNS BIT
AS
BEGIN
    DECLARE @CanTake BIT; -- Default: bisa mengambil subject
	--cek apakah subjectcode ada di tabel subject atau tidak

    -- Cek apakah ada pre-requisitenya untuk subject tertentu
    IF EXISTS (
        SELECT 1
        FROM Prerequisite  [pre]
        WHERE pre.SubjectID = (SELECT ID FROM Subject WHERE Code=@SubjectCode)
    )
		BEGIN
			-- Jika ada pre-requisite, periksa apakah mahasiswa sudah menyelesaikan pre-requisite tersebut
			IF NOT EXISTS (
				SELECT 1
				FROM Enrollment [e]
				JOIN StudentSubject [ss] ON e.ID = ss.EnrollmentID
				JOIN [Period] [p] ON p.ID = e.PeriodID
				JOIN Competency [c] ON c.ID = p.CompetencyID
				JOIN [Subject] [s] ON S.ID = C.SubjectID
				WHERE e.StudentNumber = @StudentNumber
					AND S.ID IN (
						SELECT pre.PrerequisiteID
						FROM Prerequisite [pre]
						WHERE pre.SubjectID = (SELECT ID FROM Subject WHERE Code=@SubjectCode)
					)
					AND ss.IsPassed  = 1
			)
				BEGIN
					SET @CanTake = 0; -- Mahasiswa tidak dapat mengambil subject karena belum menyelesaikan pre-requisite
				END
			ELSE
				BEGIN
					SET @CanTake = 1;
				END
		END
	ELSE
		BEGIN
			SET @CanTake = 1;
		END

    RETURN @CanTake;
END


go
/*
select dbo.CanStudentTakeSubject('2012/01/0001','48024');
select dbo.CanStudentTakeSubject('2012/01/0001','37151');
select dbo.CanStudentTakeSubject('2012/01/0001','UFWUFWVFUW');
select * from Prerequisite
select * from StudentSubject
select * from Enrollment
select * from Competency
SELECT * FROM Subject
*/
