USE Unicorn
GO
CREATE OR ALTER PROCEDURE GetAvailableSubjects
    @Tanggal DATE
AS
BEGIN
    SELECT DISTINCT
        per.StartDate [Period Start Date],
        per.EndDate [Period End Date],
        s.[Name] [Subject Name],
        ISNULL(s.[Description], 'Subject description not available') [Subject Description],
        FORMAT(s.Cost, 'C', 'en-US') [Cost]
    FROM [Subject] [s]
	JOIN Competency [com] on com.SubjectID = s.ID
    JOIN
        [Period] AS [per] ON per.CompetencyID = com.ID
    WHERE
        @Tanggal BETWEEN CONVERT(date,per.StartDate) AND CONVERT(date,per.EndDate);
END
EXEC GetAvailableSubjects '2014-01-01'