USE Unicorn
GO
-- Buat tabel pivot untuk perbandingan jumlah siswa berdasarkan jenis kelamin dan major
SELECT *
FROM (
    SELECT
        m.[Name],
		CASE 
			WHEN stu.Gender='M' THEN 'Male'
			WHEN stu.Gender='F' THEN 'Female'
		END [Gender],
        COUNT(*) [Jumlah Siswa]
    FROM
    Student [stu]
    JOIN StudentMajor [sm] ON sm.StudentNumber = stu.StudentNumber
	JOIN Major [m] ON m.ID = sm.MajorID
    GROUP BY
        m.[Name], stu.Gender
) AS TrenMajorByGender
PIVOT
(
	SUM(TrenMajorByGender.[Jumlah Siswa])
    FOR TrenMajorByGender.Gender IN ([Male], [Female])
) AS PivotTable;
