USE Unicorn
GO
CREATE OR ALTER PROCEDURE AddTutorCompetency
    @StaffNumber VARCHAR(20),
    @SubjectCode VARCHAR(10)
AS
BEGIN

    -- Periksa apakah tutor dengan Staff Number yang diinput ada dalam database
    IF NOT EXISTS (SELECT 1 FROM Tutor WHERE StaffNumber = @StaffNumber)
		BEGIN
			PRINT  'Staff Number tidak ditemukan, silahkan masukan  Staff Number kembali'
		END

    -- Periksa apakah subject dengan Subject Code yang diinput ada dalam database
    ELSE IF NOT EXISTS (SELECT 1 FROM [Subject] [s] WHERE s.Code = @SubjectCode)
		BEGIN
			PRINT 'Code Subject tidak ditemukan, silahkan masukan Code Subject kembali'
		END
	ELSE IF EXISTS(SELECT 1 FROM Competency WHERE StaffNumber=@StaffNumber AND SubjectID=(SELECT s.ID FROM [Subject] [s] WHERE s.Code = @SubjectCode))
		BEGIN
			 PRINT 'Tidak dapat menambahkan Comptency karena Competency dengan Kombinasi itu Sudah Ada'
		END
	  -- Jika tutor dan subject ada dalam database, tambahkan kompetensi
	ELSE 
		BEGIN
			INSERT INTO Competency(StaffNumber,SubjectID)
			VALUES (@StaffNumber,(SELECT s.ID FROM [Subject] [s] WHERE s.Code = @SubjectCode));
			PRINT	'Kompetensi berhasil ditambahkan'
			
		END
END
EXEC AddTutorCompetency 'CA01','48024'
