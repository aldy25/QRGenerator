USE Unicorn
GO
SELECT ci.[Name] , COUNT(stu.StudentNumber) [Jumlah Mahasiswa]
FROM Student [stu]
JOIN Country [ci] ON stu.CitizenshipID = ci.ID
GROUP BY ci.[Name]