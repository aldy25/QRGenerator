USE Unicorn
GO
CREATE OR ALTER PROCEDURE GenerateTranscript
    @StudentNumber VARCHAR(255)
AS
BEGIN
    -- Informasi mahasiswa
    SELECT
        CONCAT(stu.FirstName, ' ',stu.MiddleName, ' ', stu.LastName) [Student Fullname],
        stu.RegisterDate [Register Date],
        stu.TotalCreditPoint [Total Credit Point]
    FROM
        Student [stu]
    WHERE
       stu.StudentNumber = @StudentNumber;
    -- Detail nilai subject
    SELECT
        s.Code AS [Subject Code],
        s.[Name] AS [Subject Name],
        m.[Name] AS [Major Name],
        SUM(rc.Mark * rc.WeightedMark) AS [Total Mark],
        p.EndDate AS "End Period Date"
    FROM
        Student AS stu
    INNER JOIN
        Enrollment AS e ON stu.StudentNumber = e.StudentNumber
    INNER JOIN
        [Period] AS p ON p.ID = e.PeriodID
    INNER JOIN
        Competency AS c ON c.ID = p.CompetencyID
	INNER JOIN
        [Subject] AS s ON s.ID = c.SubjectID
    INNER JOIN
        Major AS m ON m.ID = s.MajorID
    JOIN
        StudentReportCard AS rc ON rc.StudentSubjectID = s.ID
    WHERE
        stu.StudentNumber = @StudentNumber
    GROUP BY
        s.Code, s.[Name], m.[Name], p.EndDate;
END

EXEC GenerateTranscript '2012/01/0001'