USE Unicorn
GO
SELECT
	CONCAT_WS(' ',s.FirstName, s.MiddleName, s.LastName) [Nama Lengkap],
    s.[Address] [Alamat]
FROM
    Student [s]
LEFT JOIN
    Enrollment [en] ON en.StudentNumber = s.StudentNumber
WHERE
    en.ID IS NULL;