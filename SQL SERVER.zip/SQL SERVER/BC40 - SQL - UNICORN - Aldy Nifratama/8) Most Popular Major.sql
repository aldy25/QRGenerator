USE Unicorn
GO
CREATE OR ALTER PROCEDURE GetMostPopularMajor
    @Tahun INT
AS
BEGIN

	WITH MajorCounts AS (
	SELECT
        m.[Name] [Major],
		COUNT (en.StudentNumber) [Jumlah Mahasiswa]
    FROM
	StudentMajor [sm]
	JOIN Student [s] on sm.StudentNumber = s.StudentNumber
	RIGHT JOIN Enrollment [en] ON s.StudentNumber = en.StudentNumber
	JOIN Major [m] on m.ID = sm.MajorID
    WHERE
        YEAR(en.EnrollDate) = @Tahun
    GROUP BY
		m.[Name]
	)
	SELECT
		Major,
		[Jumlah Mahasiswa]
	FROM MajorCounts
	WHERE [Jumlah Mahasiswa] = (SELECT MAX([Jumlah Mahasiswa]) FROM MajorCounts)
END
exec GetMostPopularMajor '2013'
