USE Unicorn
GO
CREATE OR ALTER PROCEDURE CompleteEnrollmentTransaction
    @EnrollmentID INT,
    @PaymentMethod VARCHAR(2)
AS
BEGIN
    DECLARE @TransactionDate DATE = GETDATE();
    DECLARE @TotalFee money;

    -- Periksa status enrollment
    DECLARE @EnrollmentStatus varchar(3);
    SELECT @EnrollmentStatus = status FROM Enrollment WHERE ID = @EnrollmentID;

    -- Jika enrollment sudah complete atau cancel, beri feedback konfirmasi
    IF (@EnrollmentStatus = 'COM')
		BEGIN
			PRINT 'Transaksi sudah '+'complete'+' Sejak Awal.';
		END
	ELSE IF (@EnrollmentStatus = 'CAN')
		BEGIN
			PRINT 'Transaksi sudah '+'dalam kondisi cancel'+' tidak bisa dibayar.';
		END
	ELSE 
		BEGIN
				--Hitung total fee berdasarkan harga subject saat ini
				SELECT @TotalFee = SUM(s.Cost)
				FROM Enrollment [e]
				INNER JOIN [Period] [p] ON p.ID = e.PeriodID
				JOIN Competency [c] ON c.ID = p.CompetencyID
				JOIN [Subject] [s] ON S.ID = C.SubjectID
				WHERE e.ID = @EnrollmentID;
				-- Update enrollment dengan payment method, transaction date, dan status complete
				UPDATE Enrollment
				SET
					PaymentMethod = @PaymentMethod,
					TransactionDate = @TransactionDate,
					status = 'COM',
					Fee = @TotalFee
				WHERE ID = @EnrollmentID;
			PRINT 'Transaksi berhasil diselesaikan.';
		END
END