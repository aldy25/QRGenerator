USE Unicorn
GO
CREATE OR ALTER PROCEDURE GetTutorsAndStudents
    @SubjectCode NVARCHAR(255),
    @Tanggal DATE
AS
BEGIN
    SELECT
        CONCAT(stu.FirstName, ' ', stu.MiddleName, ' ', stu.LastName) [Nama Siswa],
        CONCAT(t.FirstName, ' ', t.MiddleName, ' ', t.LastName) AS "Nama Tutor"
    FROM
        [Subject] AS s
    INNER JOIN
        Competency AS c ON s.ID = c.SubjectID
    INNER JOIN
		[Period] [p] on p.CompetencyID  = c.ID
    INNER JOIN
        Tutor [t] ON c.StaffNumber =t.StaffNumber
	INNER JOIN
		Major [m] on m.ID = s.MajorID
	INNER JOIN
		StudentMajor [sm] on m.ID = sm.MajorID
	INNER JOIN 
		Student [stu] on stu.StudentNumber = sm.StudentNumber 
    WHERE
        s.Code = @SubjectCode AND @Tanggal BETWEEN p.StartDate AND p.EndDate;
END
EXEC GetTutorsAndStudents 48024,'2013-06-01' 
