USE Unicorn
GO
SELECT
    m.[Name] [Major Name],
	m.TotalCreditPoint [Total Credit Point],
	(SUM(s.CreditPoint)) - (m.TotalCreditPoint) [Different with subject]
    FROM
        Major [m]
    LEFT JOIN
        Subject [s] ON  m.ID= s.MajorID
    GROUP BY
m.[Name],m.TotalCreditPoint

