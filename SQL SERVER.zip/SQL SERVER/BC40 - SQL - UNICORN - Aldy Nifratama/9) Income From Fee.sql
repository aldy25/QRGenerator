USE Unicorn
GO
CREATE OR ALTER FUNCTION CalculateTotalFeePaid
(
    @Tanggal DATE
)
RETURNS MONEY
AS
BEGIN
    DECLARE @TotalFee MONEY;
	SET @TotalFee= 
    (SELECT SUM(Fee)
    FROM Enrollment
    WHERE TransactionDate < CONVERT(DATE,@Tanggal))
    RETURN @TotalFee
END
GO
SELECT dbo.CalculateTotalFeePaid('2012-09-10') [Total Fee]


