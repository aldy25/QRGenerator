USE Unicorn
GO
SELECT CONCAT_WS(' ',s.FirstName, s.MiddleName, s.LastName) [Nama Lengkap],
		CONCAT(c.[Name],', ',FORMAT(s.BirthDate, 'dd MMMM yyyy','id')) [Kelahiran],
		CASE 
			WHEN cer.[Level] = 'B' THEN 'Bacholer'
			WHEN cer.[Level] = 'M' THEN 'Master'
			WHEN cer.[Level] = 'P' THEN 'Phd'
		END [Level],
		cer.AcademicTitle [Academic Title],
		CASE 
			WHEN cer.Grade = 'PAS' THEN 'Pass'
			WHEN cer.Grade = 'CRE' THEN 'Credit'
			WHEN cer.Grade = 'DIS' THEN 'Distinction'
			WHEN cer.Grade = 'HDS' THEN 'High Distinction'
		END [Grade],
		FORMAT(cer.GraduateDate,'dd MMMM yyyy','id') [Graduate Date]
FROM [Certificate] [cer]
	JOIN Student [s] ON s.StudentNumber = cer.StudentNumber
	JOIN City [c] on c.ID = s.BirthCityID


