﻿using System.Text.RegularExpressions;

namespace QUESTION_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ketik Angka dalam array dengan pemisahnya tanda ',' contoh : (2,4,6,5,3,1,7,9,10,8) :");
            string dataInput = Console.ReadLine();
            int[] dataArray = Array.ConvertAll(dataInput.Split(','), int.Parse);
            int[] numbers = dataArray.Where(x => x % 2 != 0).Distinct().ToArray();
            int[] sortNumbers = numbers.OrderByDescending(x => x).ToArray();
            int firstIndex = sortNumbers.First();
            List<int> result = new List<int>();
            result.Add(firstIndex);
            for (int i = 1; i<sortNumbers.Length; i++)
            {
                int sum = 0;

                for (int x= i; x<sortNumbers.Length; x++)
                {
                    sum += sortNumbers[x];
                }

                if (sum > firstIndex)
                {
                    continue;
                }
                result.Add(sortNumbers[i]);

            }
            result.ToArray();
            Console.WriteLine("Input: [{0}]", string.Join(",", dataInput));
            Console.WriteLine("Output: [{0}]", string.Join(",", result));
        }
    }
}