﻿namespace QUESTION_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Masukan Karakter, contoh (aaabbcccaaaac) : ");
            string inputData = Console.ReadLine();
            CharCounter(inputData);
        }

        public static void CharCounter(string characterInput)
        {
            char currentCharacter = characterInput[0];
            int count = 1;
            for (int i =1; i<characterInput.Length; i++ )
            {
                if (characterInput[i] == currentCharacter)
                {
                    count++;
                }
                else
                {
                    Console.WriteLine($"{currentCharacter}: {count}");
                    currentCharacter= characterInput[i];
                    count = 1;
                }
            }

            Console.WriteLine($"{currentCharacter}: {count}");
        }
    }
}